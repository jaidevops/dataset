@echo off

echo ============================================
echo Starting ViMP Execution
echo Parameter: %1
echo ============================================

echo.
echo [Step 1/2] Executing vimp_configure.bat...
call "vimp_configure.bat" "%~1"

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo ERROR: vimp_configure.bat failed with exit code %ERRORLEVEL%.
    exit /b %ERRORLEVEL%
)

echo.
echo [Step 2/2] Executing vimp_start.bat...
call "vimp_start.bat"

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo ERROR: vimp_start.bat failed with exit code %ERRORLEVEL%.
    exit /b %ERRORLEVEL%
)

echo.
echo ============================================
echo ViMP execution completed successfully.
echo ============================================