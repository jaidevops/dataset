import asyncio
import grpc
import re
import json
import os
import time
import threading
import random
import socket
import queue as thread_queue
import logging
from logging.handlers import RotatingFileHandler
import sys
import gzip
import shutil
from pathlib import Path
from rpc import datastream_service_pb2
from rpc import datastream_service_pb2_grpc


class CompressedRotatingFileHandler(RotatingFileHandler):
    """RotatingFileHandler that compresses rotated log files to .gz format."""

    def doRollover(self):
        """Override doRollover to compress old log files."""
        super().doRollover()

        rotated_file = f"{self.baseFilename}.1"
        if os.path.exists(rotated_file):
            compressed_file = f"{rotated_file}.gz"
            with open(rotated_file, 'rb') as f_in:
                with gzip.open(compressed_file, 'wb', compresslevel=9) as f_out:
                    shutil.copyfileobj(f_in, f_out)
            os.remove(rotated_file)


def setup_logging():
    """Setup optimized logging configuration with compressed file rotation."""
    log_dir = os.getenv('LOG_DIR', './logs')
    log_file = os.getenv('LOG_FILE', 'sync_log_file_server.log')
    log_max_bytes = int(os.getenv('LOG_MAX_BYTES', '10485760'))
    log_backup_count = int(os.getenv('LOG_BACKUP_COUNT', '5'))
    log_level = os.getenv('LOG_LEVEL', 'INFO').upper()

    os.makedirs(log_dir, exist_ok=True)

    logger = logging.getLogger()
    logger.setLevel(getattr(logging, log_level))
    logger.handlers.clear()

    log_path = os.path.join(log_dir, log_file)
    file_handler = CompressedRotatingFileHandler(
        log_path,
        maxBytes=log_max_bytes,
        backupCount=log_backup_count
    )
    file_formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(filename)s:%(lineno)d - %(message)s'
    )
    file_handler.setFormatter(file_formatter)
    logger.addHandler(file_handler)

    console_handler = logging.StreamHandler(sys.stdout)
    console_formatter = logging.Formatter('%(levelname)s - %(message)s')
    console_handler.setFormatter(console_formatter)
    console_handler.setLevel(logging.WARNING)
    logger.addHandler(console_handler)

    logging.getLogger('grpc').setLevel(logging.WARNING)

    return logger


def get_logger():
    """Get logger instance."""
    return logging.getLogger(__name__)


logger = setup_logging()

# gRPC retry configuration
GRPC_MAX_RETRIES = int(os.getenv("GRPC_MAX_RETRIES", "20"))
GRPC_INITIAL_RETRY_DELAY = float(os.getenv("GRPC_INITIAL_RETRY_DELAY", "1.0"))
GRPC_MAX_RETRY_DELAY = float(os.getenv("GRPC_MAX_RETRY_DELAY", "60.0"))
GRPC_BACKOFF_MULTIPLIER = float(os.getenv("GRPC_BACKOFF_MULTIPLIER", "2.0"))

# Reconnection configuration
GRPC_MAX_RECONNECT_ATTEMPTS = int(os.getenv("GRPC_MAX_RECONNECT_ATTEMPTS", "999"))
GRPC_RECONNECT_DELAY = float(os.getenv("GRPC_RECONNECT_DELAY", "5.0"))
GRPC_HEALTH_CHECK_INTERVAL = float(os.getenv("GRPC_HEALTH_CHECK_INTERVAL", "5.0"))

# VIMP directory configuration
vimp_dir = os.environ.get("VIMP_DIR", "C:/ViMP")
machine_name = socket.gethostname()
WATCH_DIR = os.path.join(vimp_dir, "SimOutput", machine_name, "Log")
os.makedirs(WATCH_DIR, exist_ok=True)

GRPC_SERVER = os.environ.get("GRPC_SERVER", "localhost:9000")

# gRPC client variables
grpc_channel = None
grpc_stub = None
data_queue = thread_queue.Queue()


def calculate_retry_delay(attempt):
    """Calculate delay with exponential backoff and jitter"""
    delay = min(
        GRPC_INITIAL_RETRY_DELAY * (GRPC_BACKOFF_MULTIPLIER**attempt),
        GRPC_MAX_RETRY_DELAY,
    )
    jitter = delay * 0.2 * (random.random() * 2 - 1)
    return max(0.1, delay + jitter)


def execute_with_retry(func, *args, **kwargs):
    """Execute a function with retry logic for gRPC operations"""
    logger = get_logger()

    for attempt in range(GRPC_MAX_RETRIES + 1):
        try:
            return func(*args, **kwargs)
        except grpc.RpcError as e:
            if e.code() in [
                grpc.StatusCode.UNAVAILABLE,
                grpc.StatusCode.DEADLINE_EXCEEDED,
                grpc.StatusCode.CANCELLED,
            ]:
                if attempt < GRPC_MAX_RETRIES:
                    delay = calculate_retry_delay(attempt)
                    logger.warning(f"RPC failed (attempt {attempt + 1}): {e.code().name} - {e.details()}")
                    logger.info(f"Retrying in {delay:.1f}s...")
                    time.sleep(delay)
                    continue
            raise
        except Exception:
            raise

    raise Exception(f"Operation failed after {GRPC_MAX_RETRIES + 1} attempts")


signal_data = {
    "EGO Velocity": None,
    "Ego Distance": None,
    "Target deceleration": None,
    "AEB Trigger": None,
    "LDWstate": None,
    "Sync Time": None,
    "SIM End Time (s)": None,
    "Event log": None,
}

patterns = {
    "Sync Time": re.compile(r"Received new sync time:\s*([-+]?\d*\.?\d+)"),
    "EGO Velocity": re.compile(r"EGO Velocity.*?([-+]?\d*\.?\d+)"),
    "Ego Distance": re.compile(r"Ego Distance.*?([-+]?\d*\.?\d+)"),
    "Target deceleration": re.compile(r"Target deceleration.*?([-+]?\d*\.?\d+)"),
    "AEB Trigger": re.compile(r"AEB Trigger.*?([-+]?\d*\.?\d+|\bON\b|\bOFF\b)"),
    "LDWstate": re.compile(r"LDWstate.*?([-+]?\d*\.?\d+)"),
}

pattern_end = {"SIM End Time (s)": re.compile(r"\b(\d*\.?\d+)s\b")}

event_logs = {
    "SIM_START",
    "Begin simulation pre-processing",
    "Cloe is ready!",
    "Finish simulation pre-processing",
}


def setup_grpc_connection_with_retry():
    """Setup gRPC connection to server with retry logic"""
    global grpc_channel, grpc_stub

    options = [
        ("grpc.keepalive_time_ms", 2147483647),
        ("grpc.keepalive_timeout_ms", 2147483647),
        ("grpc.keepalive_permit_without_calls", True),
        ("grpc.http2.max_pings_without_data", 0),
        ("grpc.http2.min_time_between_pings_ms", 0),
        ("grpc.http2.min_ping_interval_without_data_ms", 0),
        ("grpc.max_connection_idle_ms", 2147483647),
        ("grpc.max_connection_age_ms", 2147483647),
        ("grpc.max_connection_age_grace_ms", 2147483647),
    ]

    logger = get_logger()
    for attempt in range(GRPC_MAX_RETRIES + 1):
        try:
            logger.info(f"Attempting gRPC connection (attempt {attempt + 1}/{GRPC_MAX_RETRIES + 1})")

            grpc_channel = grpc.insecure_channel(GRPC_SERVER, options=options)
            grpc.channel_ready_future(grpc_channel).result(timeout=10)
            grpc_stub = datastream_service_pb2_grpc.DataStreamServiceStub(grpc_channel)
            logger.info(f"Successfully connected to gRPC server at {GRPC_SERVER}")

            def ping_test():
                return grpc_stub.Ping(
                    datastream_service_pb2.PingRequest(
                        message="Hello from ViMP Log Server!"
                    )
                )

            try:
                ping_response = execute_with_retry(ping_test)
                logger.info(f"Ping successful: {ping_response.message}")
            except grpc.RpcError as e:
                if e.code() == grpc.StatusCode.UNIMPLEMENTED:
                    logger.debug(f"Ping not implemented on server (ok): {e.code()} - {e.details()}")
                else:
                    logger.error(f"Ping failed: {e.code()} - {e.details()}")
            except Exception as e:
                logger.error(f"Ping test error: {e}")

            return True

        except grpc.FutureTimeoutError:
            logger.warning(f"Connection timeout (attempt {attempt + 1})")
        except Exception as e:
            logger.error(f"Connection failed (attempt {attempt + 1}): {e}")

        try:
            if "grpc_channel" in globals() and grpc_channel:
                grpc_channel.close()
        except Exception:
            pass

        if attempt < GRPC_MAX_RETRIES:
            delay = calculate_retry_delay(attempt)
            logger.info(f"Waiting {delay:.1f}s before retry...")
            time.sleep(delay)

    logger.error(f"Failed to connect to gRPC server after {GRPC_MAX_RETRIES + 1} attempts")
    return False


def generate_data_stream():
    """Generate data stream from queue for gRPC (synchronous version)"""
    logger = get_logger()
    stream_count = 0

    while True:
        try:
            data = data_queue.get(timeout=1)

            if data is None:
                break

            sample = datastream_service_pb2.StreamWBData()
            sample.data_type = "json"
            sample.data_source = "ViMPLogMonitor"
            sample.timestamp = int(time.time() * 1000)
            sample.payload_string = json.dumps(data)

            stream_count += 1
            if stream_count % 100 == 1:
                logger.debug(f"Streamed {stream_count} data items (signal: {data.get('signalName', 'N/A')})")
            yield sample

        except thread_queue.Empty:
            continue
        except Exception as e:
            logger.error(f"Error in data stream generator: {e}")
            break


def start_grpc_stream():
    """Start gRPC streaming in a separate thread with retry logic"""
    logger = get_logger()

    def stream_worker():
        while True:
            try:
                if grpc_stub:
                    logger.info("Starting gRPC stream worker...")

                    def stream_data():
                        return grpc_stub.StreamData(generate_data_stream())

                    response = execute_with_retry(stream_data)
                    logger.info(f"gRPC Stream completed: {response.message}")
                    break
                else:
                    logger.warning("No gRPC stub available, attempting reconnection...")
                    if setup_grpc_connection_with_retry():
                        continue
                    else:
                        logger.error("Failed to establish gRPC connection, stopping stream worker")
                        break

            except grpc.RpcError as e:
                if e.code() == grpc.StatusCode.CANCELLED:
                    logger.info("gRPC stream cancelled")
                    break
                elif e.code() in [
                    grpc.StatusCode.UNAVAILABLE,
                    grpc.StatusCode.DEADLINE_EXCEEDED,
                    grpc.StatusCode.INTERNAL,
                ]:
                    logger.warning(f"gRPC connection lost ({e.code().name}), triggering reconnection...")
                    raise ConnectionError(f"gRPC error: {e.code().name}")
                else:
                    logger.error(f"gRPC streaming error: {e.code().name} - {e.details()}")
                    break
            except ConnectionError:
                raise
            except Exception as e:
                logger.error(f"Unexpected streaming error: {e}")
                logger.info("Triggering reconnection...")
                raise ConnectionError(f"Unexpected error: {e}")

    thread = threading.Thread(target=stream_worker)
    thread.daemon = True
    thread.start()
    logger.info("gRPC stream thread started")
    return thread


async def wait_for_new_log_file():
    """Wait for a NEW .log file to appear (ignore existing ones)."""
    logger = get_logger()
    log_dir = Path(WATCH_DIR)
    log_dir.mkdir(exist_ok=True)

    existing_logs = set(log_dir.glob("*.log"))
    logger.debug(f"Ignoring existing log files: {existing_logs}")

    logger.info(f"Waiting for a NEW .log file to appear in {log_dir}...")
    while True:
        current_logs = set(log_dir.glob("*.log"))
        new_logs = current_logs - existing_logs

        if new_logs:
            log_path = max(new_logs, key=lambda f: f.stat().st_ctime)
            logger.info(f"New log file detected: {log_path}")
            return log_path

        await asyncio.sleep(0.5)


async def send_data_via_grpc(data):
    """Send data via gRPC queue"""
    data_queue.put(data)


async def tail_log(log_path, channel):
    """Read the log file from the beginning once it appears."""
    with open(log_path, "r") as f:
        buffer = []
        last_health_check = time.time()
        logger = get_logger()

        while True:
            current_time = time.time()
            if current_time - last_health_check > GRPC_HEALTH_CHECK_INTERVAL:
                try:
                    if channel is None:
                        logger.error("Channel is None - connection lost")
                        raise ConnectionError("Channel is None")

                    state = channel._channel.check_connectivity_state(True)

                    if state == 4:
                        logger.error("Channel closed - connection lost")
                        raise ConnectionError("Channel closed")
                    elif state == 3:
                        logger.warning("Channel in transient failure state")
                        raise ConnectionError("Transient failure")

                    last_health_check = current_time

                except ConnectionError:
                    raise
                except Exception as e:
                    logger.error(f"Channel health check failed: {e}")
                    raise ConnectionError(f"Health check failed: {e}")

            line = f.readline()
            if not line:
                await asyncio.sleep(0.1)
                continue

            buffer.append(line.strip())

            if len(buffer) >= 3:
                last_three = buffer[-3:]
                if (
                    last_three[0].startswith("Received new sync time:")
                    and "Run.." in last_three[0]
                    and last_three[1].startswith("Waiting at sync time:")
                ):

                    match = re.search(
                        r"Received new sync time:\s*([-+]?\d*\.?\d+)", last_three[0]
                    )
                    if match:
                        sync_time_value = match.group(1)

                        custom_data = {
                            "EGO Velocity": "0",
                            "Ego Distance": "0",
                            "Target deceleration": "0",
                            "AEB Trigger": "0",
                            "LDWstate": "0",
                            "Sync Time": sync_time_value,
                            "SIM End Time (s)": "0",
                            "Event log": "nothing",
                        }

                        await send_data_via_grpc(custom_data)
                        buffer.clear()
                        continue

            updated = False
            exist = False
            running_log = False

            for key, pattern in patterns.items():
                match = pattern.search(line)
                if match:
                    value = match.group(1)
                    signal_data[key] = value
                    updated = True

            for key, pattern in pattern_end.items():
                match_end = pattern.search(line)
                if match_end:
                    value_end = match_end.group(1)
                    signal_data[key] = value_end
                    signal_data["Sync Time"] = value_end
                    updated = True
                    if value_end != "0":
                        exist = True
                else:
                    signal_data[key] = "0"

            matched_eventlog = next((s for s in event_logs if s in line), None)
            if matched_eventlog:
                signal_data["Event log"] = matched_eventlog
                signal_data["EGO Velocity"] = "0"
                signal_data["Ego Distance"] = "0"
                signal_data["Target deceleration"] = "0"
                signal_data["AEB Trigger"] = "0"
                signal_data["LDWstate"] = "0"
                signal_data["Sync Time"] = "0"
                signal_data["SIM End Time (s)"] = "0"
                updated = True
                running_log = True
            else:
                signal_data["Event log"] = "nothing"

            if updated and all(signal_data.values()):
                await send_data_via_grpc(dict(signal_data))
                for key in signal_data:
                    signal_data[key] = None


async def run_log_monitor():
    """Main log monitoring loop with reconnection support"""
    logger = get_logger()
    reconnect_count = 0

    while reconnect_count <= GRPC_MAX_RECONNECT_ATTEMPTS:
        try:
            if not setup_grpc_connection_with_retry():
                reconnect_count += 1
                logger.warning(f"Connection failed (attempt {reconnect_count})")
                if reconnect_count > GRPC_MAX_RECONNECT_ATTEMPTS:
                    break
                await asyncio.sleep(GRPC_RECONNECT_DELAY)
                continue

            start_grpc_stream()

            while True:
                try:
                    log_path = await wait_for_new_log_file()
                    await tail_log(log_path, grpc_channel)
                    break
                except ConnectionError as e:
                    logger.warning(f"Connection lost during log tailing: {e}")
                    break

        except ConnectionError as e:
            reconnect_count += 1
            logger.warning(f"Connection Error: {e}")
            if reconnect_count > GRPC_MAX_RECONNECT_ATTEMPTS:
                logger.error("Maximum reconnection attempts reached. Exiting...")
                break
            await asyncio.sleep(GRPC_RECONNECT_DELAY)

        except KeyboardInterrupt:
            logger.info("Log monitor stopped by user")
            break

        except Exception as e:
            reconnect_count += 1
            logger.error(f"Unexpected error: {e}")
            if reconnect_count > GRPC_MAX_RECONNECT_ATTEMPTS:
                break
            await asyncio.sleep(GRPC_RECONNECT_DELAY)


if __name__ == "__main__":
    logger = get_logger()
    logger.info(f"Starting ViMP Log File Server")
    logger.info(f"Watch directory: {WATCH_DIR}")
    logger.info(f"gRPC server: {GRPC_SERVER}")

    try:
        asyncio.run(run_log_monitor())
    except KeyboardInterrupt:
        logger.info("Shutting down log server...")