import subprocess
import psutil
import re
import time
import logging
from logging.handlers import RotatingFileHandler
import sys
import os


def setup_logging():
    """Setup optimized logging configuration with file rotation."""
    log_dir = os.getenv('LOG_DIR', './logs')
    log_file = os.getenv('LOG_FILE', 'check_process.log')
    log_max_bytes = int(os.getenv('LOG_MAX_BYTES', '10485760'))
    log_backup_count = int(os.getenv('LOG_BACKUP_COUNT', '5'))
    log_level = os.getenv('LOG_LEVEL', 'INFO').upper()

    os.makedirs(log_dir, exist_ok=True)

    logger = logging.getLogger()
    logger.setLevel(getattr(logging, log_level))
    logger.handlers.clear()

    log_path = os.path.join(log_dir, log_file)
    file_handler = RotatingFileHandler(
        log_path,
        maxBytes=log_max_bytes,
        backupCount=log_backup_count
    )
    file_formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(filename)s:%(lineno)d - %(message)s'
    )
    file_handler.setFormatter(file_formatter)
    logger.addHandler(file_handler)

    console_handler = logging.StreamHandler(sys.stdout)
    console_formatter = logging.Formatter('%(levelname)s - %(message)s')
    console_handler.setFormatter(console_formatter)
    console_handler.setLevel(logging.WARNING)
    logger.addHandler(console_handler)

    return logger


def get_logger():
    """Get logger instance."""
    return logging.getLogger(__name__)


# Initialize logging
logger = setup_logging()


def check_process_running(process_name):
    """Check if a process with the given name is running"""
    for proc in psutil.process_iter(["name"]):
        if proc.info["name"].lower() == process_name.lower():
            return True
    return False


def wait_for_process(process_name, timeout=10):
    """Wait for a process to start within timeout seconds"""
    start_time = time.time()
    while time.time() - start_time < timeout:
        if check_process_running(process_name):
            return True
        time.sleep(0.1)
    return False


def run_batch_file_and_monitor(batch_file_path, cwd=None, env=None):
    """Run the batch file and monitor its output"""
    logger = get_logger()
    vimp_running = "stop"

    popen_kwargs = dict(
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        bufsize=1,
        universal_newlines=True,
    )
    if cwd:
        popen_kwargs['cwd'] = cwd
    if env is not None:
        popen_kwargs['env'] = env
    else:
        popen_kwargs['env'] = os.environ.copy()

    logger.info(f"Running batch: {batch_file_path} cwd={popen_kwargs.get('cwd')} VIMP_DIR={popen_kwargs['env'].get('VIMP_DIR')}")

    process = subprocess.Popen(batch_file_path, **popen_kwargs)

    while True:
        output_line = process.stdout.readline()
        if output_line == "" and process.poll() is not None:
            break
        if output_line:
            logger.debug(output_line.strip())

            # Check for "Starting ViMP" in the output (case insensitive)
            if re.search(r"Starting ViMP", output_line, re.IGNORECASE):
                logger.info("Found 'Starting ViMP' in logs - waiting for MATLAB process...")

                # Wait for MATLAB process to start (10 second timeout)
                if wait_for_process("MATLAB.exe", 10):
                    logger.info("MATLAB.exe started - ViMP launching")
                    vimp_running = "running"
                    break
                else:
                    logger.warning("Timeout: MATLAB.exe did not start within 10 seconds")
                    break

    return process.poll(), vimp_running


def kill_and_wait(process_names, timeout=10):
    """Kill given processes and wait until they are terminated"""
    logger = get_logger()

    for proc in psutil.process_iter(["pid", "name"]):
        try:
            if proc.info["name"] and proc.info["name"].lower() in [
                name.lower() for name in process_names
            ]:
                proc.kill()
                logger.info(f"Sent kill signal to: {proc.info['name']} (PID: {proc.info['pid']})")
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            pass

    start_time = time.time()
    while time.time() - start_time < timeout:
        still_running = False
        for proc in psutil.process_iter(["name"]):
            if proc.info["name"] and proc.info["name"].lower() in [
                name.lower() for name in process_names
            ]:
                still_running = True
                break
        if not still_running:
            return "stop"
        time.sleep(0.2)

    return "running"


def restart_python_process(script_name="vWIA_sync_log_file_server.py", timeout=10):
    """Find and restart a Python process running a specific script"""
    logger = get_logger()

    killed = False
    for proc in psutil.process_iter(["pid", "name", "cmdline"]):
        try:
            cmdline = proc.info["cmdline"]
            if cmdline and script_name in " ".join(cmdline):
                proc.kill()
                logger.info(f"Killed existing process: {proc.pid} running {script_name}")
                killed = True
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            pass

    start_time = time.time()
    while time.time() - start_time < timeout:
        found = False
        for proc in psutil.process_iter(["cmdline"]):
            try:
                cmdline = proc.info["cmdline"]
                if cmdline and script_name in " ".join(cmdline):
                    found = True
                    break
            except Exception:
                continue
        if not found:
            break
        time.sleep(0.2)

    try:
        python_exe = sys.executable
        script_path = os.path.abspath(script_name)

        if os.name == 'nt':
            subprocess.Popen(
                [python_exe, script_path],
                creationflags=subprocess.CREATE_NEW_PROCESS_GROUP,
                cwd=os.path.dirname(script_path) if os.path.dirname(script_path) else None,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                stdin=subprocess.DEVNULL
            )
        else:
            subprocess.Popen(
                [python_exe, script_path],
                start_new_session=True,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                stdin=subprocess.DEVNULL
            )
        logger.info(f"Started {script_name} again with Python: {python_exe}")
    except Exception as e:
        logger.error(f"Failed to start {script_name}: {e}")
        return False

    start_time = time.time()
    while time.time() - start_time < timeout:
        for proc in psutil.process_iter(["cmdline"]):
            try:
                cmdline = proc.info["cmdline"]
                if cmdline and script_name in " ".join(cmdline):
                    logger.info(f"{script_name} is running again.")
                    return True
            except Exception:
                continue
        time.sleep(0.2)

    logger.warning(f"Timeout: {script_name} did not start within {timeout} seconds.")
    return False