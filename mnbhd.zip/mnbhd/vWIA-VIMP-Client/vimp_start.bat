@echo off
setlocal
 
set "SCRIPT_DIR=%~dp0"
set "VIMP_CFG1=%SCRIPT_DIR%vimp.cfg"
set "VIMP_CFG2=C:\ViMP\vimp.cfg"
set "BACK1=%VIMP_CFG1%.bak"
set "BACK2=%VIMP_CFG2%.bak"
 
if exist "%VIMP_CFG1%" (
    copy /Y "%VIMP_CFG1%" "%BACK1%" >nul
)
 
if exist "%VIMP_CFG2%" (
    copy /Y "%VIMP_CFG2%" "%BACK2%" >nul
)
 
powershell.exe -ExecutionPolicy Bypass -File "C:\ViMP_Script_1\ViMP_Scripts\run_vimp_and_cleanup.ps1"
set "PS_EXIT=%ERRORLEVEL%"
 
:: If the PowerShell script removed the cfg files, restore from backups
if not exist "%VIMP_CFG1%" if exist "%BACK1%" (
    copy /Y "%BACK1%" "%VIMP_CFG1%" >nul
)
 
if not exist "%VIMP_CFG2%" if exist "%BACK2%" (
    copy /Y "%BACK2%" "%VIMP_CFG2%" >nul
)
 
endlocal
exit /b %PS_EXIT