# vWIA VIMP Client Service

> gRPC streaming client for ViMP (Vehicle Integration & Modeling Platform) simulation control via MATLAB.

**Last Updated:** 2026-07-15  
**Status:** ✅ **Operational** - All core functionality working with enhanced resilience

---

## Table of Contents

- [Current Operational Status](#current-operational-status)
- [Recent Fixes & Improvements](#recent-fixes--improvements)
- [Overview](#overview)
- [Architecture](#architecture)
- [File Structure](#file-structure)
- [gRPC Protocol](#grpc-protocol)
- [Installation](#installation)
- [Configuration](#configuration)
- [Service Management](#service-management)
- [Supported Commands](#supported-commands)
- [Logs](#logs)
- [Monitoring & Verification](#monitoring--verification)
- [Troubleshooting](#troubleshooting)
- [Known Limitations](#known-limitations)

---

## Current Operational Status

### ✅ What's Working (as of 2026-07-15)

| Component | Status | Details |
|-----------|--------|---------|
| **gRPC Connection** | ✅ Working | Bidirectional streaming to localhost:9000 with auto-reconnection |
| **Command Reception** | ✅ Working | Receives `StreamWebEvent` commands from vWIA server |
| **Action Detection** | ✅ Enhanced | Detects actions from JSON payload AND event fields (fallback) |
| **launch_vimp** | ✅ Working | Kills MATLAB → restarts sync server → runs `vimp_start.bat` → MATLAB launches |
| **stop_vimp** | ✅ Working | Kills all MATLAB.exe processes with timeout |
| **pause_vimp** | ✅ Working | Suspends MATLAB processes (CPU frozen, memory retained) |
| **resume_vimp** | ✅ Working | Resumes suspended MATLAB processes |
| **configure_vimp** | ⚠️ Partial | Writes `vimp_config.json` (MATLAB ViMPguiAPI integration pending) |
| **Auto-Reconnection** | ✅ Working | Exponential backoff retry on connection loss |
| **Log Rotation** | ✅ Working | 10 MB max, 5 backups per log file |
| **Process Monitoring** | ✅ Working | `check_process.py` monitors MATLAB lifecycle |

### 🔄 Current Process Flow

```
Server sends command → Client receives StreamWebEvent → Parse payload → Execute action → Send response
```

**Example: launch_vimp execution flow:**
```
1. Server: [vimp_vm] cmd-1784100735234 from (empty payload)
2. Client: Detects empty JSON → infers action from event_name pattern
3. Client: kill_and_wait(["MATLAB.exe"]) - cleanup previous instance
4. Client: restart_python_process("vWIA_sync_log_file_server.py")
5. Client: run_batch_file_and_monitor("vimp_start.bat")
6. Client: Wait for "Starting ViMP" in batch output
7. Client: Confirm MATLAB.exe process started
8. Client: Send VIMP_RESPONSE back to server with status: "running"
```

### 📊 Active Processes (Typical)

| Process | PID | Purpose |
|---------|-----|---------|
| `python main.py` | ~2660 | VIMP client gRPC streaming |
| `MATLAB.exe` | ~9900 | ViMP simulation engine |
| `python vWIA_sync_log_file_server.py` | ~4676 | Log file monitor & streamer |

---

## Recent Fixes & Improvements

### Bug Fixes (2026-07-15)

#### 1. **JSON Parse Error: `Expecting value: line 1 column 1 (char 0)`**
**Problem:** Server sends empty or timestamp-only payloads (`'2026-07-15T07:22:53.305Z'`) instead of JSON.  
**Impact:** Client crashed with `json.JSONDecodeError` on every message.  
**Fix:** Added try/except with `literal_eval()` fallback for Python dict format.

```python
# Before: Crashed on empty payload
obj = json.loads(outer_json)

# After: Graceful fallback
try:
    obj = json.loads(outer_json)
except (json.JSONDecodeError, ValueError):
    try:
        obj = literal_eval(outer_json)
    except Exception:
        obj = {}
```

#### 2. **`'int' object has no attribute 'get'`**
**Problem:** `json.loads()` returned primitive types (int/number) instead of dict.  
**Impact:** Calling `.get()` on int caused AttributeError crash.  
**Fix:** Added `isinstance(obj, dict)` check before accessing dict methods.

```python
if not isinstance(obj, dict):
    logger.warning(f"Expected JSON object but got {type(obj).__name__}")
    obj = {}
```

#### 3. **`vimp_running` Undefined Variable**
**Problem:** If `restart_python_process()` returned False, `vimp_running` was never set.  
**Impact:** `UnboundLocalError` when trying to use `vimp_running`.  
**Fix:** Initialize `vimp_running = "error"` before conditional block.

```python
vimp_running = "error"  # Default value
if restart_python_process("vWIA_sync_log_file_server.py"):
    exit_code, vimp_running = run_batch_file_and_monitor("vimp_start.bat")
```

#### 4. **Action Not Executed When Payload Empty** ⭐ **Critical Fix**
**Problem:** Server sends `cmd-*` messages with empty payloads. Client detected the action but **only sent a response without executing it**.  
**Impact:** VIMP was never launched - MATLAB never started.  
**Fix:** Added full action execution in the "JSON payload not found" fallback path.

```python
# Before: Only sent response, never executed
else:
    response_data["vimp"] = {"status": "JSON payload not found"}
    send_vimp_response(fallback_action, response_data, event_generator)

# After: Executes the inferred action
else:
    if fallback_action == "launch_vimp":
        kill_and_wait(["MATLAB.exe"])
        if restart_python_process("vWIA_sync_log_file_server.py"):
            exit_code, vimp_running = run_batch_file_and_monitor("vimp_start.bat")
        response_data["vimp"] = {"status": vimp_running, ...}
    elif fallback_action == "stop_vimp":
        # ... execute stop logic
    # ... other actions
    send_vimp_response(fallback_action, response_data, event_generator)
```

#### 5. **Missing `messageId` in Responses**
**Problem:** Responses didn't include `messageId` for server correlation.  
**Impact:** Server couldn't match responses to original commands.  
**Fix:** Added `messageId` to all response payloads.

### Enhancement: Action Detection from Event Fields

**Problem:** Server inconsistently sends `action_vimp` in JSON payload. Sometimes it's in `event_name` or `event_type` fields.

**Solution:** Multi-layer action detection:
1. **Primary:** Extract from JSON payload (`obj.get("action_vimp")`)
2. **Fallback 1:** Reconstruct from `StreamWebEvent` fields (`event_type`, `event_name`, `source`)
3. **Fallback 2:** Parse `event_name` pattern:
   - `cmd-configure-*` → `configure_vimp`
   - `cmd-start-*` / `cmd-launch-*` → `launch_vimp`
   - `cmd-stop-*` → `stop_vimp`
   - `cmd-pause-*` → `pause_vimp`
   - `cmd-resume-*` → `resume_vimp`
   - `cmd-*` (default) → `launch_vimp`

### Enhancement: Comprehensive Logging

Added `>>> EXECUTING` log markers for visibility:
```
>>> EXECUTING launch_vimp for messageId: cmd-1784100735234
>>> launch_vimp completed with status: running
```

---

## Overview

The **vWIA VIMP Client** is a Windows service that manages ViMP simulation sessions through a bidirectional gRPC streaming connection. It receives commands from a central vWIA server (launch, stop, pause, resume, configure) and executes them by controlling MATLAB/ViMP processes on the host machine.

**Key capabilities:**
- Bidirectional gRPC streaming (`StreamEvents`) with auto-reconnection
- MATLAB/ViMP process lifecycle management (launch, stop, pause/resume)
- Configuration via JSON file for MATLAB consumption
- Log file monitoring via companion sync server (`vWIA_sync_log_file_server.py`)
- NSSM-based Windows service with exponential backoff retry

---

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                     vWIA Server (Remote)                        │
│              Sends commands via gRPC StreamEvents               │
└────────────────────────────┬────────────────────────────────────┘
                             │ gRPC Stream (bidirectional)
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│              vWIA-VIMP-Client-Service (NSSM)                    │
│                                                                 │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │  main.py  (gRPC Client + Command Router)                 │   │
│  │                                                          │   │
│  │  Receives:  START | STOP | PAUSE | RESUME | CONFIGURE    │   │
│  │  Sends:     VIMP_RESPONSE events back to server          │   │
│  └──────────┬──────────────────────────┬─────────────────────┘   │
│             │                          │                          │
│     ┌───────▼───────┐        ┌────────▼────────┐                │
│     │ check_process │        │ vimp_start.bat  │                │
│     │   .py         │        │ vimp_configure  │                │
│     └───────────────┘        │     .bat        │                │
│                              └────────┬────────┘                │
│                                       │                         │
│                              ┌────────▼────────┐                │
│                              │  MATLAB.exe     │                │
│                              │  (ViMP Sim)     │                │
│                              └─────────────────┘                │
│                                                                 │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │  vWIA_sync_log_file_server.py  (Log Monitor)             │   │
│  │  Watches:  VIMP_DIR/SimOutput/<hostname>/Log/             │   │
│  │  Streams signal data via gRPC StreamData                  │   │
│  └──────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
```

---

## File Structure

```
C:\vWIA-VIMP-Client\
├── main.py                          # Core gRPC client + command router
├── check_process.py                 # Process utilities (launch, kill, restart)
├── vWIA_sync_log_file_server.py     # Log file monitor + signal data streamer
├── vimp_start.bat                   # MATLAB headless launch script
├── vimp_configure.bat               # Configuration script (SME-blocked placeholder)
├── requirements.txt                 # Python dependencies
├── logs/                            # Runtime logs (auto-created)
│   ├── vimp_client.log              # Main client log (rotating)
│   ├── check_process.log            # Process management log
│   ├── sync_log_file_server.log     # Log sync server log
│   ├── service-stdout.log           # NSSM stdout capture
│   └── service-stderr.log           # NSSM stderr capture
└── rpc/
    ├── __init__.py                  # Package init
    ├── datastream_service.proto     # Protocol Buffers definition
    ├── datastream_service_pb2.py    # Generated protobuf stubs
    └── datastream_service_pb2_grpc.py  # Generated gRPC stubs
```

---

## gRPC Protocol

**Service:** `vWIA.DataStreamService`
**Transport:** gRPC insecure (no TLS)
**Default Port:** 9000

### Messages

| Message | Direction | Description |
|---------|-----------|-------------|
| `PingRequest` / `PingReply` | Client → Server | Connection health check |
| `StreamWBEvent` | Client → Server | Outgoing events (responses, telemetry) |
| `StreamWebEvent` | Server → Client | Incoming commands from server |
| `StreamWBLogData` | Client → Server | Log data streaming (via sync server) |
| `StreamWBData` | Client → Server | Signal data streaming (via sync server) |

### Service Definition

```protobuf
service DataStreamService {
  rpc StreamLogs   (stream StreamWBLogData)    returns (stream StreamLogsResponse);
  rpc StreamData   (stream StreamWBData)       returns (stream StreamDataResponse);
  rpc StreamEvents (stream StreamWBEvent)      returns (stream StreamWebEvent);
  rpc Ping         (PingRequest)               returns (PingReply);
}
```

### Regenerating Protobuf Stubs

```bash
pip install grpcio-tools
python -m grpc_tools.protoc -I. --python_out=. --grpc_python_out=. datastream_service.proto
```

> **Important:** The generated `datastream_service_pb2_grpc.py` requires a relative import fix:
> ```python
> # Change this line:
> import datastream_service_pb2 as datastream__service__pb2
> # To:
> from . import datastream_service_pb2 as datastream__service__pb2
> ```

---

## Installation

### Prerequisites

| Requirement | Version | Notes |
|-------------|---------|-------|
| Python | 3.10+ | Tested with 3.14 |
| MATLAB | R2021b+ | Required for ViMP simulation |
| NSSM | 2.24 | Windows service wrapper |
| gRPC Server | — | Must be running and accessible |

### Step 1: Deploy Files

```powershell
# Extract to target directory
Expand-Archive -Path vWIA-VIMP-Client.zip -DestinationPath C:\vWIA-VIMP-Client -Force

# Verify all files present
Get-ChildItem C:\vWIA-VIMP-Client\
Get-ChildItem C:\vWIA-VIMP-Client\rpc\
```

### Step 2: Install Python Dependencies

```powershell
cd C:\vWIA-VIMP-Client
pip install -r requirements.txt
```

### Step 3: Create Logs Directory

```powershell
New-Item -ItemType Directory -Path "C:\vWIA-VIMP-Client\logs" -Force
```

### Step 4: Register NSSM Service

```powershell
# Register service
C:\nssm-2.24\win64\nssm.exe install vWIA-VIMP-Client-Service "C:\Windows\System32\cmd.exe" "/c python main.py"

# Set working directory
C:\nssm-2.24\win64\nssm.exe set vWIA-VIMP-Client-Service AppDirectory "C:\vWIA-VIMP-Client"

# Set display name and description
C:\nssm-2.24\win64\nssm.exe set vWIA-VIMP-Client-Service Description "vWIA VIMP VM Client - Manages ViMP simulation via gRPC"

# Set environment variables
C:\nssm-2.24\win64\nssm.exe set vWIA-VIMP-Client-Service AppEnvironmentExtra "VIMP_DIR=C:\ViMP;MATLAB_EXE=C:\Program Files\MATLAB\R2024a\bin\matlab.exe;GRPC_SERVER_HOST=<SERVER_IP>;GRPC_SERVER_PORT=9000"

# Set log output
C:\nssm-2.24\win64\nssm.exe set vWIA-VIMP-Client-Service AppStdout "C:\vWIA-VIMP-Client\logs\service-stdout.log"
C:\nssm-2.24\win64\nssm.exe set vWIA-VIMP-Client-Service AppStderr "C:\vWIA-VIMP-Client\logs\service-stderr.log"

# Set restart behavior
C:\nssm-2.24\win64\nssm.exe set vWIA-VIMP-Client-Service AppRestartDelay 2000
C:\nssm-2.24\win64\nssm.exe set vWIA-VIMP-Client-Service AppExit Restart restart

# Set startup type to automatic
C:\nssm-2.24\win64\nssm.exe set vWIA-VIMP-Client-Service Start SERVICE_AUTO_START

# Start the service
C:\nssm-2.24\win64\nssm.exe start vWIA-VIMP-Client-Service
```

---

## Configuration

### Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `GRPC_SERVER_HOST` | `localhost` | gRPC server hostname/IP |
| `GRPC_SERVER_PORT` | `9000` | gRPC server port |
| `GRPC_MAX_RETRIES` | `20` | Max connection retry attempts |
| `GRPC_INITIAL_RETRY_DELAY` | `1.0` | Initial retry delay (seconds) |
| `GRPC_MAX_RETRY_DELAY` | `60.0` | Max retry delay (seconds) |
| `GRPC_BACKOFF_MULTIPLIER` | `2.0` | Exponential backoff multiplier |
| `VIMP_DIR` | `C:/ViMP` | ViMP installation directory |
| `MATLAB_EXE` | `C:\Program Files\MATLAB\R2024a\bin\matlab.exe` | MATLAB executable path |
| `MATLAB_SCRIPT_DIR` | `%VIMP_DIR%\scripts` | ViMP MATLAB scripts directory |
| `VIMP_LAUNCH_TIMEOUT` | `60` | Timeout for VIMP launch (seconds) |
| `LOG_DIR` | `./logs` | Log output directory |
| `LOG_LEVEL` | `INFO` | Log level (DEBUG, INFO, WARNING, ERROR) |
| `LOG_MAX_BYTES` | `10485760` | Max log file size (10 MB) |
| `LOG_BACKUP_COUNT` | `5` | Number of rotated log files to keep |

### Log Sync Server Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `GRPC_SERVER` | `localhost:9000` | gRPC server address (host:port) |
| `GRPC_MAX_RECONNECT_ATTEMPTS` | `999` | Max reconnection attempts |
| `GRPC_RECONNECT_DELAY` | `5.0` | Reconnection delay (seconds) |
| `GRPC_HEALTH_CHECK_INTERVAL` | `5.0` | Health check interval (seconds) |

---

## Service Management

### Check Service Status

```powershell
Get-Service -Name vWIA-VIMP-Client-Service | Select-Object Name, Status, StartType
```

### Start / Stop / Restart

```powershell
Start-Service -Name vWIA-VIMP-Client-Service
Stop-Service  -Name vWIA-VIMP-Client-Service -Force
Restart-Service -Name vWIA-VIMP-Client-Service -Force
```

### View NSSM Configuration

```powershell
C:\nssm-2.24\win64\nssm.exe edit vWIA-VIMP-Client-Service
```

### View Service Logs

```powershell
# NSSM captured output
Get-Content "C:\vWIA-VIMP-Client\logs\service-stdout.log" -Tail 50
Get-Content "C:\vWIA-VIMP-Client\logs\service-stderr.log" -Tail 50

# Application logs
Get-Content "C:\vWIA-VIMP-Client\logs\vimp_client.log" -Tail 50

# Windows Event Log (NSSM events)
Get-EventLog -LogName Application -Source nssm -Newest 20 |
    Where-Object { $_.Message -match 'vWIA-VIMP-Client' } |
    Format-List TimeGenerated, EntryType, Message
```

---

## Supported Commands

Commands are received via `StreamEvents` gRPC stream from the server. Each incoming `StreamWebEvent` contains a JSON payload with an `action_vimp` field.

### `launch_vimp`

Launches ViMP simulation via MATLAB headless mode.

**Process:**
1. Kill any existing MATLAB processes
2. Restart log sync server (`vWIA_sync_log_file_server.py`)
3. Execute `vimp_start.bat` which launches MATLAB in batch mode
4. Monitor for "Starting ViMP" output and wait for `MATLAB.exe` process

**Response:**
```json
{
  "vimp": {
    "status": "running",
    "pid": 0,
    "timestamp": "2026-07-14T14:31:14"
  }
}
```

### `stop_vimp`

Stops ViMP by killing all MATLAB processes.

**Process:**
1. Find all `MATLAB.exe` processes
2. Send termination signal
3. Wait for process exit (with timeout)

**Response:**
```json
{
  "vimp": {
    "status": "stopped",
    "pid": 0,
    "timestamp": "2026-07-14T14:31:14"
  }
}
```

### `pause_vimp`

Pauses ViMP by suspending MATLAB processes (CPU time frozen, memory retained).

**Process:**
1. Find all `MATLAB.exe` processes
2. Call `proc.suspend()` on each
3. Collect suspended PIDs

**Response:**
```json
{
  "vimp": {
    "status": "PAUSED",
    "suspended_pids": [1234, 5678],
    "timestamp": "2026-07-14T14:31:14"
  }
}
```

### `resume_vimp`

Resumes previously paused ViMP by resuming MATLAB processes.

**Process:**
1. Find all `MATLAB.exe` processes in `STATUS_STOPPED` state
2. Call `proc.resume()` on each
3. Collect resumed PIDs

**Response:**
```json
{
  "vimp": {
    "status": "RUNNING",
    "resumed_pids": [1234, 5678],
    "timestamp": "2026-07-14T14:31:14"
  }
}
```

### `configure_vimp`

Configures ViMP with assembly, variant, and maneuver settings.

**Input:**
```json
{
  "messageId": "corr-123",
  "assemblyName": "Vehicle_Assembly_V2",
  "variant": "Standard_Config",
  "maneuvers": ["LaneChange", "BrakingTest", "US06"]
}
```

**Process:**
1. Extract configuration fields from payload
2. Write `vimp_config.json` to `%VIMP_DIR%`
3. **Placeholder:** Real MATLAB ViMPguiAPI call pending SME input

**Response:**
```json
{
  "vimp": {
    "status": "VALIDATING",
    "messageId": "corr-123",
    "assemblyName": "Vehicle_Assembly_V2",
    "variant": "Standard_Config",
    "maneuvers": ["LaneChange", "BrakingTest", "US06"],
    "detail": "Configuration written to vimp_config.json",
    "timestamp": "2026-07-14T14:31:14"
  }
}
```

---

## Logs

### Log Files

| File | Source | Rotation |
|------|--------|----------|
| `logs/vimp_client.log` | `main.py` | 10 MB, 5 backups |
| `logs/check_process.log` | `check_process.py` | 10 MB, 5 backups |
| `logs/sync_log_file_server.log` | `vWIA_sync_log_file_server.py` | 10 MB, 5 backups, compressed (.gz) |
| `logs/service-stdout.log` | NSSM stdout capture | Manual rotation |
| `logs/service-stderr.log` | NSSM stderr capture | Manual rotation |

### Log Format

```
2026-07-14 14:31:14,123 - __main__ - INFO - main.py:456 - Successfully connected to gRPC server on 10.0.0.1:9000
```

### Log Levels

| Level | Usage |
|-------|-------|
| DEBUG | Detailed diagnostic information |
| INFO | Normal operation events |
| WARNING | Recoverable issues, retry attempts |
| ERROR | Actionable failures |

---

## Monitoring & Verification

### Quick Status Check

```powershell
# Complete status dashboard
Write-Host "=== VIMP Client Status ===" -ForegroundColor Cyan
Get-Process python* -ErrorAction SilentlyContinue | Where-Object { $_.Id -ne $PID } | 
    Select-Object Id, ProcessName, @{N='CMD';E={(Get-CimInstance Win32_Process -Filter "ProcessId=$($_.Id)").CommandLine}} | Format-Table -AutoSize

Write-Host "`n=== MATLAB/ViMP Status ===" -ForegroundColor Cyan
Get-Process MATLAB* -ErrorAction SilentlyContinue | 
    Select-Object Id, ProcessName, StartTime, @{N='CPU(s)';E={[math]::Round($_.CPU,2)}} | Format-Table -AutoSize

Write-Host "`n=== Latest Log Entries ===" -ForegroundColor Cyan
Get-Content C:\vWIA-VIMP-Client\logs\vimp_client.log -Tail 15
```

### Real-Time Log Monitoring

```powershell
# Watch for new messages in real-time
Get-Content C:\vWIA-VIMP-Client\logs\vimp_client.log -Wait -Tail 3

# Filter for specific events
Get-Content C:\vWIA-VIMP-Client\logs\vimp_client.log -Wait | Select-String "EXECUTING|Response|VIMP response"
```

### Verify Action Execution

```powershell
# Check if launch_vimp executed successfully
Get-Content C:\vWIA-VIMP-Client\logs\vimp_client.log | Select-String "EXECUTING|completed|queued for action" | Select-Object -Last 10

# Check MATLAB process status
Get-Process MATLAB* -ErrorAction SilentlyContinue

# Check sync server status
Get-Process python* | Where-Object { $_.CommandLine -like "*sync_log*" }
```

### Expected Log Flow for `launch_vimp`

```
INFO - Response 1: [vimp_vm] cmd-1784100735234 from 
DEBUG - Raw event_payload (len=24): '2026-07-15T07:32:15.234Z'
WARNING - JSON payload not found in event string - event_type=vimp_vm, event_name=cmd-1784100735234
INFO - Inferred action 'launch_vimp' from event fields for messageId: cmd-1784100735234
INFO - >>> EXECUTING launch_vimp for messageId: cmd-1784100735234
INFO - Started vWIA_sync_log_file_server.py again
INFO - vWIA_sync_log_file_server.py is running again
INFO - >>> launch_vimp completed with status: running
INFO - VIMP response queued for action: launch_vimp
DEBUG - Sending dynamic event 1: [VIMP_RESPONSE] vimp_action_result from VimpVM
```

---

## Troubleshooting

### Service Stuck in Paused State

**Symptom:** `Get-Service` shows `Paused` status.

**Root Causes & Fixes:**

| Cause | Fix |
|-------|-----|
| Missing `logs` directory | `New-Item -ItemType Directory -Path "C:\vWIA-VIMP-Client\logs" -Force` |
| Protobuf version mismatch | Regenerate stubs (see [Regenerating Protobuf Stubs](#regenerating-protobuf-stubs)) |
| NSSM restart loop | Check `service-stderr.log` for exit code 1 errors |

**Recovery Steps:**
```powershell
# 1. Check error logs
Get-Content "C:\vWIA-VIMP-Client\logs\service-stderr.log" -Tail 20

# 2. Check Windows Event Log
Get-EventLog -LogName Application -Source nssm -Newest 10 |
    Where-Object { $_.Message -match 'vWIA-VIMP-Client' }

# 3. Stop and restart
Stop-Service  -Name vWIA-VIMP-Client-Service -Force
Start-Service -Name vWIA-VIMP-Client-Service
```

### Protobuf Version Mismatch

**Symptom:** `TypeError: Couldn't parse file content!`

**Cause:** Generated `.pb2.py` files were compiled with a different protobuf version than installed.

**Fix:**
```powershell
# Check installed version
python -c "import google.protobuf; print(google.protobuf.__version__)"

# Regenerate stubs
pip install grpcio-tools
python -m grpc_tools.protoc -I. --python_out=. --grpc_python_out=. datastream_service.proto

# Fix relative import in pb2_grpc.py
# Change:  import datastream_service_pb2 as ...
# To:      from . import datastream_service_pb2 as ...

# Clear cached bytecode
Remove-Item "__pycache__" -Recurse -Force
Remove-Item "rpc\__pycache__" -Recurse -Force
```

### Service Fails to Start (Exit Code 1)

**Symptom:** NSSM logs show "Program exited with return code 1".

**Check:**
```powershell
# Run manually to see the error
cd C:\vWIA-VIMP-Client
python main.py
```

**Common Causes:**
- Missing Python dependencies → `pip install -r requirements.txt`
- Missing `logs` directory → create it
- Missing `rpc/` files → verify all 4 files present
- gRPC server unreachable → check `GRPC_SERVER_HOST`/`GRPC_SERVER_PORT`

### MATLAB Not Found

**Symptom:** `vimp_start.bat` fails with "MATLAB not found".

**Fix:**
```powershell
# Set correct MATLAB path in NSSM
C:\nssm-2.24\win64\nssm.exe set vWIA-VIMP-Client-Service AppEnvironmentExtra "MATLAB_EXE=C:\Program Files\MATLAB\R2024a\bin\matlab.exe"

# Restart service
Restart-Service -Name vWIA-VIMP-Client-Service -Force
```

### gRPC Connection Failures

**Symptom:** Logs show "Connection timeout" or "Failed to connect".

**Check:**
```powershell
# Verify server is reachable
Test-NetConnection -ComputerName <SERVER_IP> -Port 9000

# Check firewall
Get-NetFirewallRule | Where-Object { $_.DisplayName -match 'grpc|9000' }
```

---

## Known Limitations

| Limitation | Status | Notes |
|------------|--------|-------|
| `configure_vimp` uses JSON file placeholder | ⏳ SME-blocked | Awaiting exact MATLAB ViMPguiAPI signature |
| `vimp_headless_start.m` MATLAB script | ⏳ Pending | Content depends on ViMP project structure |
| No TLS/mTLS support | By design | Uses gRPC insecure channel |
| PID tracking returns 0 | Known | MATLAB spawns child processes; parent PID unreliable |
| Pause/Resume uses process suspend | Known | MATLAB may not handle `suspend()` gracefully in all cases |
| Log sync server auto-restart on launch | Known | `vWIA_sync_log_file_server.py` is restarted on each `launch_vimp` |

---

## Dependencies

| Package | Version | Purpose |
|---------|---------|---------|
| `grpcio` | ≥1.62 | gRPC runtime |
| `protobuf` | ≥4.21 | Protocol Buffers runtime |
| `psutil` | ≥5.9 | Process management |
| `numpy` | ≥1.24 | Numeric data handling |
| `click` | ≥8.1 | CLI utilities |

---

## Service Account

The service runs as **LocalSystem** (default NSSM configuration). This provides:
- Full access to MATLAB installation directories
- Ability to suspend/resume processes
- Network access for gRPC connections
- Write access to `C:\vWIA-VIMP-Client\logs\`

---

## Quick Reference

```powershell
# Status
Get-Service -Name vWIA-VIMP-Client-Service

# Logs
Get-Content "C:\vWIA-VIMP-Client\logs\vimp_client.log" -Tail 50 -Wait

# Restart
Restart-Service -Name vWIA-VIMP-Client-Service -Force

# NSSM config GUI
C:\nssm-2.24\win64\nssm.exe edit vWIA-VIMP-Client-Service

# Uninstall (if needed)
C:\nssm-2.24\win64\nssm.exe remove vWIA-VIMP-Client-Service confirm
```