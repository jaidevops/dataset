import grpc
from rpc import datastream_service_pb2
from rpc import datastream_service_pb2_grpc
import time
import logging
from logging.handlers import RotatingFileHandler
import json
import threading
import queue
import os
import sys
import psutil
import random
import shutil
from datetime import datetime
from ast import literal_eval
from check_process import (
    run_batch_file_and_monitor,
    kill_and_wait,
    restart_python_process,
)

"""
vWIA VIMP EventStream Client with Retry Support

Environment Variables:
- GRPC_SERVER_HOST: gRPC server hostname (default: localhost)
- GRPC_SERVER_PORT: gRPC server port (default: 9000)
- GRPC_MAX_RETRIES: Maximum number of retry attempts (default: 5)
- GRPC_INITIAL_RETRY_DELAY: Initial delay between retries in seconds (default: 1.0)
- GRPC_MAX_RETRY_DELAY: Maximum delay between retries in seconds (default: 60.0)
- GRPC_BACKOFF_MULTIPLIER: Exponential backoff multiplier (default: 2.0)
- VIMP_DIR: VIMP installation directory path
- MATLAB_SCRIPT_DIR: Directory containing ViMP MATLAB scripts
- VIMP_LAUNCH_TIMEOUT: Timeout in seconds for VIMP launch (default: 60)
- LOG_DIR: Log directory (default: ./logs)
"""


def setup_logging():
    """Setup optimized logging configuration with file rotation."""
    log_dir = os.getenv('LOG_DIR', './logs')
    log_file = os.getenv('LOG_FILE', 'vimp_client.log')
    log_max_bytes = int(os.getenv('LOG_MAX_BYTES', '10485760'))
    log_backup_count = int(os.getenv('LOG_BACKUP_COUNT', '5'))
    log_level = os.getenv('LOG_LEVEL', 'DEBUG').upper()

    os.makedirs(log_dir, exist_ok=True)

    logger = logging.getLogger()
    logger.setLevel(getattr(logging, log_level))
    logger.handlers.clear()

    log_path = os.path.join(log_dir, log_file)
    file_handler = RotatingFileHandler(
        log_path,
        maxBytes=log_max_bytes,
        backupCount=log_backup_count
    )
    file_formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(filename)s:%(lineno)d - %(message)s'
    )
    file_handler.setFormatter(file_formatter)
    logger.addHandler(file_handler)

    console_handler = logging.StreamHandler(sys.stdout)
    console_formatter = logging.Formatter('%(levelname)s - %(message)s')
    console_handler.setFormatter(console_formatter)
    console_handler.setLevel(logging.WARNING)
    logger.addHandler(console_handler)

    logging.getLogger('grpc').setLevel(logging.WARNING)

    return logger


def get_logger():
    """Get logger instance."""
    return logging.getLogger(__name__)


logger = setup_logging()

# VIMP directory and script paths
vimp_dir = os.environ.get("VIMP_DIR", "C:/ViMP")
os.environ["VIMP_DIR"] = vimp_dir
matlab_script_dir = os.environ.get("MATLAB_SCRIPT_DIR", "")
vimp_launch_timeout = int(os.environ.get("VIMP_LAUNCH_TIMEOUT", "60"))

# gRPC server configuration
GRPC_SERVER_HOST = os.environ.get("GRPC_SERVER_HOST", "localhost")
GRPC_SERVER_PORT = os.environ.get("GRPC_SERVER_PORT", "9000")

# Retry configuration
MAX_RETRIES = int(os.environ.get("GRPC_MAX_RETRIES", "20"))
INITIAL_RETRY_DELAY = float(os.environ.get("GRPC_INITIAL_RETRY_DELAY", "1.0"))
MAX_RETRY_DELAY = float(os.environ.get("GRPC_MAX_RETRY_DELAY", "60.0"))
BACKOFF_MULTIPLIER = float(os.environ.get("GRPC_BACKOFF_MULTIPLIER", "2.0"))
VIMP_CONFIGURE_BAT = os.environ.get(
    "VIMP_CONFIGURE_BAT", r"C:\vWIA-VIMP-Client\vimp_configure.bat"
)
VIMP_BATCH_DIR = os.path.dirname(VIMP_CONFIGURE_BAT)


def _preserve_vimp_cfg():
    cfg_candidates = [
        os.path.join(VIMP_BATCH_DIR, "vimp.cfg"),
        os.path.join(vimp_dir, "vimp.cfg"),
    ]

    for cfg_path in cfg_candidates:
        if os.path.isfile(cfg_path):
            backup_path = cfg_path + ".bak"
            shutil.copy2(cfg_path, backup_path)
            return cfg_path, backup_path

    return None, None


def _restore_vimp_cfg(cfg_path, backup_path):
    if cfg_path and backup_path and os.path.isfile(backup_path):
        shutil.copy2(backup_path, cfg_path)


def create_grpc_channel_with_retry():
    """Create gRPC channel with retry logic and exponential backoff"""
    options = [
        ("grpc.keepalive_time_ms", 2147483647),
        ("grpc.keepalive_timeout_ms", 2147483647),
        ("grpc.keepalive_permit_without_calls", True),
        ("grpc.http2.max_pings_without_data", 0),
        ("grpc.http2.min_time_between_pings_ms", 0),
        ("grpc.http2.min_ping_interval_without_data_ms", 0),
        ("grpc.max_connection_idle_ms", 2147483647),
        ("grpc.max_connection_age_ms", 2147483647),
        ("grpc.max_connection_age_grace_ms", 2147483647),
    ]

    logger = get_logger()

    for attempt in range(MAX_RETRIES + 1):
        try:
            logger.info(f"Attempting gRPC connection (attempt {attempt + 1}/{MAX_RETRIES + 1})")

            channel = grpc.insecure_channel(
                f"{GRPC_SERVER_HOST}:{GRPC_SERVER_PORT}", options=options
            )

            grpc.channel_ready_future(channel).result(timeout=10)
            logger.info(f"Successfully connected to gRPC server on {GRPC_SERVER_HOST}:{GRPC_SERVER_PORT}")
            return channel

        except grpc.FutureTimeoutError:
            logger.warning(f"Connection timeout (attempt {attempt + 1})")
        except Exception as e:
            logger.warning(f"Connection failed (attempt {attempt + 1}): {e}")

        try:
            if "channel" in locals():
                channel.close()
                logger.debug("Closed failed channel")
        except Exception:
            pass

        if attempt < MAX_RETRIES:
            delay = min(
                INITIAL_RETRY_DELAY * (BACKOFF_MULTIPLIER**attempt), MAX_RETRY_DELAY
            )
            jitter = delay * 0.2 * (random.random() * 2 - 1)
            actual_delay = max(0.1, delay + jitter)

            logger.info(f"Waiting {actual_delay:.1f}s before retry...")
            time.sleep(actual_delay)

    logger.warning(f"Failed to connect to gRPC server after {MAX_RETRIES + 1} attempts - will retry in outer loop")
    raise ConnectionError(
        f"Failed to connect to gRPC server after {MAX_RETRIES + 1} attempts"
    )


def execute_with_retry(func, *args, **kwargs):
    """Execute a function with retry logic for gRPC operations"""
    logger = get_logger()

    for attempt in range(MAX_RETRIES + 1):
        try:
            return func(*args, **kwargs)
        except grpc.RpcError as e:
            if e.code() in [
                grpc.StatusCode.UNAVAILABLE,
                grpc.StatusCode.DEADLINE_EXCEEDED,
            ]:
                if attempt < MAX_RETRIES:
                    delay = min(
                        INITIAL_RETRY_DELAY * (BACKOFF_MULTIPLIER**attempt),
                        MAX_RETRY_DELAY,
                    )
                    logger.warning(f"RPC failed (attempt {attempt + 1}): {e.code().name} - {e.details()}")
                    logger.info(f"Retrying in {delay:.1f}s...")
                    time.sleep(delay)
                    continue
            raise
        except Exception:
            raise

    raise Exception(f"Operation failed after {MAX_RETRIES + 1} attempts")


class EventStreamGenerator:
    def __init__(self):
        self.event_count = 0
        self.stop_event = threading.Event()
        self.dynamic_events = queue.Queue()

    def add_dynamic_event(self, event):
        """Add a dynamic event to be sent immediately"""
        self.dynamic_events.put(event)

    def generateSampleEventStream(self):
        """Generate continuous sample event stream data"""
        try:
            while not self.stop_event.is_set():
                try:
                    dynamic_event = self.dynamic_events.get(timeout=1.0)

                    self.event_count += 1
                    wb_event = datastream_service_pb2.StreamWBEvent()

                    wb_event.event_type = dynamic_event["type"]
                    wb_event.timestamp = int(time.time() * 1000)
                    wb_event.event_name = dynamic_event["name"]
                    wb_event.event_source = dynamic_event["source"]

                    payload = dynamic_event["payload"].copy()
                    payload["event_count"] = self.event_count
                    payload["timestamp"] = wb_event.timestamp
                    wb_event.event_payload = json.dumps(payload)

                    logger = get_logger()
                    logger.debug(f"Sending dynamic event {self.event_count}: [{dynamic_event['type']}] {dynamic_event['name']} from {dynamic_event['source']}")
                    yield wb_event

                except queue.Empty:
                    continue

        except Exception as e:
            logger = get_logger()
            logger.error(f"Stream generator error after {self.event_count} events: {e}")
        finally:
            logger = get_logger()
            logger.info(f"Event generator stopped after {self.event_count} events")

    def stop(self):
        """Stop the event stream generation"""
        self.stop_event.set()


def send_vimp_response(action_vimp, response_data, event_generator):
    """Send VIMP action response back to server"""
    try:
        response_event = {
            "type": "VIMP_RESPONSE",
            "name": "vimp_action_result",
            "source": "VimpVM",
            "payload": {
                "original_action": action_vimp,
                "response_data": response_data,
                "confirmed_at": int(time.time() * 1000),
                "client_id": "vwia_vimp_vm",
            },
        }

        event_generator.add_dynamic_event(response_event)
        logger = get_logger()
        logger.info(f"VIMP response queued for action: {action_vimp}")

    except Exception as e:
        logger = get_logger()
        logger.error(f"Error sending VIMP response: {e}")


def launch_vimp(event_generator):
    """Launch VIMP via MATLAB headless script"""
    logger = get_logger()
    response_data = {}

    try:
        cfg_path, cfg_backup_path = _preserve_vimp_cfg()

        # Kill previous MATLAB/ViMP processes
        kill_and_wait(["MATLAB.exe"])

        # Restart log sync server
        if restart_python_process("vWIA_sync_log_file_server.py"):
            _restore_vimp_cfg(cfg_path, cfg_backup_path)

            # Launch VIMP via batch script
            batch_file = os.path.join(VIMP_BATCH_DIR, "vimp_start.bat")
            logger.info(f"Will execute batch file for launch: {batch_file} (no params)")
            exit_code, vimp_running = run_batch_file_and_monitor(batch_file, cwd=VIMP_BATCH_DIR)

            response_data["vimp"] = {
                "status": vimp_running,
                "pid": 0,
                "timestamp": datetime.now().isoformat(),
                "exit_code": exit_code,
            }
            print(exit_code)
        else:
            response_data["vimp"] = {
                "status": "error",
                "detail": "Failed to restart log sync server",
                "timestamp": datetime.now().isoformat(),
            }

    except Exception as e:
        logger.error(f"Error launching VIMP: {e}")
        response_data["vimp"] = {
            "status": "error",
            "detail": str(e),
            "timestamp": datetime.now().isoformat(),
        }

    return response_data


def stop_vimp(event_generator):
    """Stop VIMP by killing MATLAB processes"""
    logger = get_logger()
    response_data = {}

    try:
        logger.info("Stopping VIMP: killing MATLAB processes")
        vimp_stop = kill_and_wait(["MATLAB.exe"])

        response_data["vimp"] = {
            "status": vimp_stop,
            "pid": 0,
            "timestamp": datetime.now().isoformat(),
        }

    except Exception as e:
        logger.error(f"Error stopping VIMP: {e}")
        response_data["vimp"] = {
            "status": "error",
            "detail": str(e),
            "timestamp": datetime.now().isoformat(),
        }

    return response_data


def pause_vimp(event_generator):
    """Pause VIMP by suspending MATLAB process"""
    logger = get_logger()
    response_data = {}

    try:
        suspended_pids = []
        for proc in psutil.process_iter(["pid", "name"]):
            try:
                if proc.info["name"] and proc.info["name"].lower() == "matlab.exe":
                    proc.suspend()
                    suspended_pids.append(proc.info["pid"])
                    logger.info(f"Suspended MATLAB process PID: {proc.info['pid']}")
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                pass

        response_data["vimp"] = {
            "status": "PAUSED",
            "suspended_pids": suspended_pids,
            "timestamp": datetime.now().isoformat(),
        }

    except Exception as e:
        logger.error(f"Error pausing VIMP: {e}")
        response_data["vimp"] = {
            "status": "error",
            "detail": str(e),
            "timestamp": datetime.now().isoformat(),
        }

    return response_data


def resume_vimp(event_generator):
    """Resume VIMP by resuming MATLAB process"""
    logger = get_logger()
    response_data = {}

    try:
        resumed_pids = []
        for proc in psutil.process_iter(["pid", "name", "status"]):
            try:
                if proc.info["name"] and proc.info["name"].lower() == "matlab.exe":
                    if proc.status() == psutil.STATUS_STOPPED:
                        proc.resume()
                        resumed_pids.append(proc.info["pid"])
                        logger.info(f"Resumed MATLAB process PID: {proc.info['pid']}")
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                pass

        response_data["vimp"] = {
            "status": "RUNNING",
            "resumed_pids": resumed_pids,
            "timestamp": datetime.now().isoformat(),
        }

    except Exception as e:
        logger.error(f"Error resuming VIMP: {e}")
        response_data["vimp"] = {
            "status": "error",
            "detail": str(e),
            "timestamp": datetime.now().isoformat(),
        }

    return response_data


def configure_vimp(config_payload, event_generator):
    """Configure VIMP with assemblyName, variant, and maneuvers."""
    logger = get_logger()
    response_data = {}

    try:
        message_id = config_payload.get("messageId", "")
        assembly_name = config_payload.get("assemblyName", "")
        variant = config_payload.get("variant", "")
        maneuvers = config_payload.get("maneuvers", [])

        logger.info(f"Configuring VIMP - assembly: {assembly_name}, variant: {variant}, maneuvers: {maneuvers}")

        config_file_path = os.path.join(vimp_dir, "vimp_config.json")
        config_data = {
            "assemblyName": assembly_name,
            "variant": variant,
            "maneuvers": maneuvers,
            "timestamp": datetime.now().isoformat(),
        }
        with open(config_file_path, "w", encoding="utf-8") as f:
            json.dump(config_data, f, indent=2)
        logger.info(f"VIMP config written to {config_file_path}")

        maneuver_arg = maneuvers[0] if maneuvers else ""

        import subprocess

        batch_file = os.environ.get(
            "VIMP_CONFIGURE_BAT", r"C:\vWIA-VIMP-Client\vimp_configure.bat"
        )
        if maneuver_arg:
            logger.info(f"Will execute configure batch file: {batch_file} with param: {maneuver_arg}")
            cmd = [batch_file, maneuver_arg]
        else:
            logger.info(f"Will execute configure batch file: {batch_file} (no params)")
            cmd = [batch_file]

        logger.info(f"Starting configure batch: cmd={cmd} cwd={vimp_dir}")
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=vimp_launch_timeout,
            cwd=vimp_dir,
        )
        logger.info(f"Configure batch completed: returncode={result.returncode}")
        if result.stdout:
            logger.debug(f"Configure batch stdout: {result.stdout.strip()[:1000]}")
        if result.stderr:
            logger.debug(f"Configure batch stderr: {result.stderr.strip()[:1000]}")

        response_data["vimp"] = {
            "status": "CONFIGURED" if result.returncode == 0 else "error",
            "messageId": message_id,
            "assemblyName": assembly_name,
            "variant": variant,
            "maneuvers": maneuvers,
            "batch_file": batch_file,
            "batch_arg": maneuver_arg,
            "exit_code": result.returncode,
            "stdout": result.stdout.strip(),
            "stderr": result.stderr.strip(),
            "timestamp": datetime.now().isoformat(),
        }

    except Exception as e:
        logger.error(f"Error configuring VIMP: {e}")
        response_data["vimp"] = {
            "status": "error",
            "messageId": config_payload.get("messageId", ""),
            "detail": str(e),
            "timestamp": datetime.now().isoformat(),
        }

    return response_data


def run():
    try:
        channel = create_grpc_channel_with_retry()

        try:
            stub = datastream_service_pb2_grpc.DataStreamServiceStub(channel)

            # Test ping
            try:
                def ping_test():
                    return stub.Ping(
                        datastream_service_pb2.PingRequest(
                            message="Hello from VIMP EventStream Client!"
                        )
                    )

                logger = get_logger()
                ping_response = execute_with_retry(ping_test)
                logger.info(f"Ping successful: {ping_response.message}")
            except grpc.RpcError as e:
                logger = get_logger()
                if e.code() == grpc.StatusCode.UNIMPLEMENTED:
                    logger.debug(f"Ping not implemented on server (ok): {e.code()} - {e.details()}")
                else:
                    logger.error(f"Ping failed: {e.code()} - {e.details()}")
            except Exception as e:
                logger = get_logger()
                logger.error(f"Ping test error: {e}")

            logger = get_logger()
            logger.info("Starting continuous VIMP event stream...")
            logger.info("Press Ctrl+C to stop the stream")

            event_generator = EventStreamGenerator()
            response_count = 0

            def process_responses(response_stream):
                """Process incoming response stream in a separate thread"""
                nonlocal response_count
                try:
                    logger = get_logger()
                    logger.info("Listening for server responses...")

                    for response in response_stream:
                        response_count += 1
                        if response_count % 10 == 1 or response_count <= 3:
                            logger.info(f"Response {response_count}: [{response.event_type}] {response.event_name} from {response.source}")

                        response_data = {}
                        s_event_payload = response.event_payload
                        logger.debug(f"Raw event_payload (len={len(s_event_payload)}): {repr(s_event_payload[:500])}")
                        start = s_event_payload.find("{")
                        end = len(s_event_payload) - s_event_payload[::-1].find("}")

                        outer_json = s_event_payload[start:end] if start >= 0 else ""
                        if outer_json:
                            try:
                                obj = json.loads(outer_json)
                            except (json.JSONDecodeError, ValueError):
                                # Try literal_eval for Python dict format (e.g., single quotes)
                                try:
                                    obj = literal_eval(outer_json)
                                except Exception as e:
                                    logger.warning(f"Failed to parse payload as JSON or dict: {e} - payload: {outer_json[:200]}")
                                    obj = None

                            # Ensure obj is a dict before calling .get()
                            if not isinstance(obj, dict):
                                logger.warning(f"Expected JSON object but got {type(obj).__name__} - treating as empty payload")
                                obj = {}

                            # Fallback: build obj from response fields when payload is empty or missing keys
                            if not obj.get("service_name") and not obj.get("messageId"):
                                # Try to reconstruct from StreamWebEvent fields
                                obj["service_name"] = response.event_type
                                obj["messageId"] = response.event_name
                                obj["source"] = response.source
                                logger.info(f"Reconstructed payload from event fields: service_name={obj['service_name']}, messageId={obj['messageId']}")

                            service_name = obj.get("service_name")
                            if service_name != "vimp_vm":
                                logger.debug(f"Ignoring message from source: {service_name}")
                                continue

                            action_vimp = obj.get("action_vimp")
                            vimp_test_config = obj.get("vimp_test_config")
                            version = obj.get("version")
                            uptime = obj.get("uptime")
                            message_id = obj.get("messageId", "")

                            # Fallback: extract action from event_name if action_vimp is missing
                            if not action_vimp:
                                event_name_lower = response.event_name.lower().strip()
                                # Map event_name patterns to a minimal set of actions
                                if "configure" in event_name_lower or "config" in event_name_lower:
                                    action_vimp = "configure_vimp"
                                elif "start" in event_name_lower or "launch" in event_name_lower:
                                    action_vimp = "launch_vimp"
                                elif "stop" in event_name_lower:
                                    action_vimp = "stop_vimp"
                                else:
                                    logger.warning(f"No supported action found in payload or event_name for messageId: {message_id} - event_name='{response.event_name}'")

                                if action_vimp:
                                    logger.info(f"Mapped event_name '{response.event_name}' to action: {action_vimp}")

                            logger.info(f"Processing VIMP action: {action_vimp} (messageId: {message_id}, version: {version}, uptime: {uptime})")
                            logger.debug(f"Full event payload fields: event_type={response.event_type}, event_name={response.event_name}, source={response.source}, payload_len={len(response.event_payload)}")

                            if action_vimp == "launch_vimp":
                                logger.info(f">>> EXECUTING launch_vimp for messageId: {message_id}")
                                cfg_path, cfg_backup_path = _preserve_vimp_cfg()

                                # Kill previous VIMP process
                                kill_and_wait(["MATLAB.exe"])
                                # Handle socket launch
                                vimp_running = "error"
                                if restart_python_process(
                                    "vWIA_sync_log_file_server.py"
                                ):
                                    _restore_vimp_cfg(cfg_path, cfg_backup_path)

                                    batch_to_run = os.path.join(VIMP_BATCH_DIR, "vimp_start.bat")
                                    logger.info(f"Executing batch file for launch: {batch_to_run} (no params)")
                                    exit_code, vimp_running = run_batch_file_and_monitor(batch_to_run, cwd=VIMP_BATCH_DIR)
                                    logger.info(f"Launch batch finished: exit_code={exit_code}, vimp_running={vimp_running}")
                                logger.info(f">>> launch_vimp completed with status: {vimp_running}")
                                response_data["vimp"] = {
                                    "status": vimp_running,
                                    "pid": 0,
                                    "timestamp": datetime.now().isoformat(),
                                    "messageId": message_id,
                                }

                            elif action_vimp == "stop_vimp":
                                logger.info(f">>> EXECUTING stop_vimp for messageId: {message_id}")
                                vimp_stop = kill_and_wait(["MATLAB.exe"])
                                logger.info(f">>> stop_vimp completed with status: {vimp_stop}")
                                response_data["vimp"] = {
                                    "status": vimp_stop,
                                    "pid": 0,
                                    "timestamp": datetime.now().isoformat(),
                                    "messageId": message_id,
                                }

                            elif action_vimp == "pause_vimp":
                                logger.info(f">>> EXECUTING pause_vimp for messageId: {message_id}")
                                pause_result = pause_vimp(event_generator)
                                response_data["vimp"] = pause_result["vimp"]
                                response_data["vimp"]["messageId"] = message_id

                            elif action_vimp == "resume_vimp":
                                logger.info(f">>> EXECUTING resume_vimp for messageId: {message_id}")
                                resume_result = resume_vimp(event_generator)
                                response_data["vimp"] = resume_result["vimp"]
                                response_data["vimp"]["messageId"] = message_id

                            elif action_vimp == "configure_vimp":
                                logger.info(f">>> EXECUTING configure_vimp for messageId: {message_id}")
                                # Parse the vimp_test_config as the configure payload
                                config_payload = {}
                                if vimp_test_config:
                                    try:
                                        config_payload = literal_eval(vimp_test_config)
                                    except Exception:
                                        try:
                                            config_payload = json.loads(vimp_test_config)
                                        except Exception:
                                            config_payload = {}

                                # Also check for inline configure fields in the message
                                config_payload.setdefault("assemblyName", obj.get("assemblyName", ""))
                                config_payload.setdefault("variant", obj.get("variant", ""))
                                config_payload.setdefault("maneuvers", obj.get("maneuvers", []))
                                config_payload.setdefault("messageId", obj.get("messageId", ""))

                                configure_result = configure_vimp(config_payload, event_generator)
                                response_data["vimp"] = configure_result["vimp"]

                            else:
                                logger.warning(f"Unknown action_vimp: {action_vimp} for messageId: {message_id}")
                                response_data["vimp"] = {
                                    "status": "Not matching action",
                                    "pid": 0,
                                    "timestamp": datetime.now().isoformat(),
                                    "messageId": message_id,
                                    "unknown_action": action_vimp,
                                }

                            send_vimp_response(action_vimp, response_data, event_generator)
                        else:
                            logger.warning(f"JSON payload not found in event string - event_type={response.event_type}, event_name={response.event_name}, source={response.source}")
                            # Try to extract action from event fields (limited to configure/start/stop)
                            event_name_lower = response.event_name.lower().strip()
                            if "configure" in event_name_lower or "config" in event_name_lower:
                                fallback_action = "configure_vimp"
                            elif "start" in event_name_lower or "launch" in event_name_lower:
                                fallback_action = "launch_vimp"
                            elif "stop" in event_name_lower:
                                fallback_action = "stop_vimp"
                            else:
                                fallback_action = "unknown"

                            fallback_message_id = response.event_name
                            logger.info(f"Inferred action '{fallback_action}' from event fields for messageId: {fallback_message_id}")

                            # Execute the inferred action
                            if fallback_action == "launch_vimp":
                                logger.info(f"Executing launch_vimp for messageId: {fallback_message_id}")
                                cfg_path, cfg_backup_path = _preserve_vimp_cfg()

                                kill_and_wait(["MATLAB.exe"])
                                vimp_running = "error"
                                if restart_python_process("vWIA_sync_log_file_server.py"):
                                    _restore_vimp_cfg(cfg_path, cfg_backup_path)

                                    batch_to_run = os.path.join(VIMP_BATCH_DIR, "vimp_start.bat")
                                    logger.info(f"Executing batch file for launch (fallback): {batch_to_run} (no params)")
                                    exit_code, vimp_running = run_batch_file_and_monitor(batch_to_run, cwd=VIMP_BATCH_DIR)
                                    logger.info(f"Fallback launch batch finished: exit_code={exit_code}, vimp_running={vimp_running}")
                                response_data["vimp"] = {
                                    "status": vimp_running,
                                    "pid": 0,
                                    "timestamp": datetime.now().isoformat(),
                                    "messageId": fallback_message_id,
                                }
                            elif fallback_action == "stop_vimp":
                                logger.info(f"Executing stop_vimp for messageId: {fallback_message_id}")
                                vimp_stop = kill_and_wait(["MATLAB.exe"])
                                response_data["vimp"] = {
                                    "status": vimp_stop,
                                    "pid": 0,
                                    "timestamp": datetime.now().isoformat(),
                                    "messageId": fallback_message_id,
                                }
                            elif fallback_action == "pause_vimp":
                                logger.info(f"Executing pause_vimp for messageId: {fallback_message_id}")
                                pause_result = pause_vimp(event_generator)
                                response_data["vimp"] = pause_result["vimp"]
                                response_data["vimp"]["messageId"] = fallback_message_id
                            elif fallback_action == "resume_vimp":
                                logger.info(f"Executing resume_vimp for messageId: {fallback_message_id}")
                                resume_result = resume_vimp(event_generator)
                                response_data["vimp"] = resume_result["vimp"]
                                response_data["vimp"]["messageId"] = fallback_message_id
                            elif fallback_action == "configure_vimp":
                                logger.info(f"Executing configure_vimp for messageId: {fallback_message_id}")
                                configure_result = configure_vimp({"messageId": fallback_message_id}, event_generator)
                                response_data["vimp"] = configure_result["vimp"]
                            else:
                                logger.warning(f"Cannot execute unknown action for messageId: {fallback_message_id}")
                                response_data["vimp"] = {
                                    "status": "unknown action",
                                    "pid": 0,
                                    "timestamp": datetime.now().isoformat(),
                                    "messageId": fallback_message_id,
                                    "inferred_action": fallback_action,
                                }

                            send_vimp_response(fallback_action, response_data, event_generator)

                except grpc.RpcError as e:
                    logger.warning(f"Response stream error: {e.code()} - {e.details()}")
                    if e.code() == grpc.StatusCode.UNAVAILABLE:
                        raise ConnectionError("Server unavailable")
                    elif e.code() == grpc.StatusCode.DEADLINE_EXCEEDED:
                        raise ConnectionError("Stream timeout")
                    elif e.code() == grpc.StatusCode.CANCELLED:
                        raise ConnectionError("Stream cancelled")
                    elif e.code() == grpc.StatusCode.INTERNAL:
                        raise ConnectionError("Internal error")
                    else:
                        raise ConnectionError(f"gRPC error: {e.code().name}")
                except Exception as e:
                    logger.warning(f"Response processing error: {e} - will attempt reconnection")
                    raise ConnectionError(f"Response error: {e}")
                finally:
                    logger.info(f"Response stream ended. Total received: {response_count}")

            try:
                def start_streaming():
                    return stub.StreamEvents(
                        event_generator.generateSampleEventStream()
                    )

                response_stream = execute_with_retry(start_streaming)

                response_thread = threading.Thread(
                    target=process_responses, args=(response_stream,)
                )
                response_thread.daemon = True
                response_thread.start()

                logger.info("VIMP event streaming and response listener started!")

                try:
                    connection_check_interval = 5
                    last_check = time.time()

                    while response_thread.is_alive():
                        time.sleep(0.1)

                        current_time = time.time()
                        if current_time - last_check > connection_check_interval:
                            try:
                                state = channel._channel.check_connectivity_state(True)

                                if state == 4:
                                    logger.warning("Channel shutdown detected - will attempt reconnection")
                                    raise ConnectionError("Channel closed")
                                elif state == 3:
                                    logger.warning("Channel in transient failure - will attempt reconnection")
                                    raise ConnectionError("Transient failure")

                                grpc.channel_ready_future(channel).result(timeout=2)
                                last_check = current_time

                            except grpc.FutureTimeoutError:
                                logger.warning("Connection health check timeout - server may be down")
                                raise ConnectionError("Health check timeout")
                            except ConnectionError:
                                raise
                            except Exception as e:
                                logger.warning(f"Connection health check failed: {e}")
                                raise ConnectionError(f"Health check failed: {e}")

                except ConnectionError as e:
                    logger.warning(f"Connection lost: {e} - triggering reconnection")
                    raise
                except KeyboardInterrupt:
                    logger.info("User interrupted stream")
                    raise

                response_thread.join(timeout=5)

                logger.info(f"Final Statistics - Events sent: {event_generator.event_count}, Responses received: {response_count}")

            except ConnectionError:
                event_generator.stop()
                logger.warning("Stopping event generator due to connection loss")
                raise
            except grpc.RpcError as e:
                event_generator.stop()
                logger.warning(f"StreamEvents failed: {e.code()} - {e.details()}")
                if e.code() == grpc.StatusCode.UNAVAILABLE:
                    raise ConnectionError("Server unavailable")
                elif e.code() == grpc.StatusCode.CANCELLED:
                    raise ConnectionError("Channel closed")
                elif e.code() == grpc.StatusCode.DEADLINE_EXCEEDED:
                    raise ConnectionError("Deadline exceeded")
                elif e.code() == grpc.StatusCode.UNIMPLEMENTED:
                    raise ConnectionError("RPC not implemented")
                else:
                    raise ConnectionError(f"RPC error: {e.code().name}")

        except KeyboardInterrupt:
            logger.info("Shutting down by user request...")
            try:
                event_generator.stop()
            except Exception:
                pass
            raise
        except ConnectionError:
            try:
                event_generator.stop()
            except Exception:
                pass
            raise
        except Exception as e:
            logger.warning(f"Unexpected error in main execution: {e}")
            try:
                event_generator.stop()
            except Exception:
                pass
            raise ConnectionError(f"Unexpected error: {e}")
        finally:
            try:
                channel.close()
                logger.debug("Channel closed")
            except Exception:
                pass

    except KeyboardInterrupt:
        raise
    except ConnectionError:
        raise
    except Exception as e:
        logger = get_logger()
        logger.warning(f"Failed to establish connection: {e}")
        logger.info(f"Troubleshooting: Verify server is running on {GRPC_SERVER_HOST}:{GRPC_SERVER_PORT}")
        raise ConnectionError(f"Connection failed: {e}")


def test_connection():
    """Test if the server is reachable with retry logic"""
    logger = get_logger()
    try:
        channel = create_grpc_channel_with_retry()
        channel.close()
        return True
    except ConnectionError as e:
        logger.warning(f"Cannot establish connection to server: {e}")
        logger.info(f"Make sure your Java gRPC server is running on {GRPC_SERVER_HOST}:{GRPC_SERVER_PORT}")
        return False
    except Exception as e:
        logger.warning(f"Unexpected error during connection test: {e}")
        logger.info(f"Make sure your Java gRPC server is running on {GRPC_SERVER_HOST}:{GRPC_SERVER_PORT}")
        return False


if __name__ == "__main__":
    logger = get_logger()
    logger.info("vWIA VIMP EventStream Client with Auto-Reconnection")
    logger.info(f"Target Server: {GRPC_SERVER_HOST}:{GRPC_SERVER_PORT}")
    logger.info(f"Max Connection Retries: {MAX_RETRIES}, Initial Delay: {INITIAL_RETRY_DELAY}s, Max Delay: {MAX_RETRY_DELAY}s, Backoff: {BACKOFF_MULTIPLIER}x")
    logger.info(f"VIMP Directory: {vimp_dir}")

    max_reconnect_attempts = int(os.environ.get("GRPC_MAX_RECONNECT_ATTEMPTS", "999"))
    reconnect_delay = float(os.environ.get("GRPC_RECONNECT_DELAY", "5.0"))
    reconnect_count = 0

    while reconnect_count <= max_reconnect_attempts:
        try:
            if reconnect_count > 0:
                logger.info(f"Reconnection Attempt #{reconnect_count} - Waiting {reconnect_delay}s before reconnecting...")
                time.sleep(reconnect_delay)

            if reconnect_count == 0:
                if not test_connection():
                    logger.warning("Initial connection failed. Starting retry sequence...")
                    reconnect_count += 1
                    continue

            logger.info("Starting gRPC streaming session...")
            run()

            logger.info("Session ended normally")
            break

        except ConnectionError as e:
            reconnect_count += 1
            logger.warning(f"Connection Error: {e}")
            logger.info(f"Reconnection attempt {reconnect_count}/{max_reconnect_attempts}")

            if reconnect_count > max_reconnect_attempts:
                logger.error(f"Maximum reconnection attempts ({max_reconnect_attempts}) reached. Exiting...")
                break

            current_delay = min(reconnect_delay * (1.5 ** (reconnect_count - 1)), 60.0)
            logger.info(f"Will reconnect in {current_delay:.1f}s...")
            time.sleep(current_delay - reconnect_delay if current_delay > reconnect_delay else 0)

        except KeyboardInterrupt:
            logger.info("Application stopped by user (Ctrl+C)")
            break

        except Exception as e:
            reconnect_count += 1
            logger.warning(f"Unexpected error (will retry): {e}")
            logger.info(f"Reconnection attempt {reconnect_count}/{max_reconnect_attempts}")

            if reconnect_count > max_reconnect_attempts:
                logger.error(f"Maximum reconnection attempts ({max_reconnect_attempts}) reached. Exiting...")
                break

            current_delay = min(reconnect_delay * (1.5 ** (reconnect_count - 1)), 60.0)
            logger.info(f"Will reconnect in {current_delay:.1f}s...")
            time.sleep(current_delay - reconnect_delay if current_delay > reconnect_delay else 0)

    logger.info("Application terminated")
    if reconnect_count > 0:
        logger.info(f"Total reconnections: {reconnect_count}")
    else:
        logger.info(f"Troubleshooting: Start vWIA service on port {GRPC_SERVER_PORT}, check network, firewall, and server logs")