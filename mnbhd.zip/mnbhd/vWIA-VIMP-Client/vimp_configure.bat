@echo off
setlocal

if "%~1"=="" (
    echo Usage: RunViMP.bat "HCP1 RTC: initial slow line maneuvering"
    exit /b 1
)

set "ManeuverHeadlines=%~1"

powershell.exe -ExecutionPolicy Bypass -File "C:\ViMP_Script_1\ViMP_Scripts\Initial_cfg_setup.ps1" -ManeuverHeadlines "%ManeuverHeadlines%" -DebugLookup

if %ERRORLEVEL% NEQ 0 (
    echo PowerShell script execution failed.
    exit /b %ERRORLEVEL%
)

echo PowerShell script executed successfully.
exit /b 0