<#
.SYNOPSIS
    Generates a new ViMP .cfg file from a template, replacing vehicle, settings,
    and the full maneuver block so the file stays internally consistent.
#>
param (
    [string]$NewVehicleAssembly = "991C2S_SEO390",
    [string]$NewMatlabVersion   = "2021b_Update 2_PCWIN64",
    [int]$SaveReportValue       = 1,
    [string[]]$ManeuverHeadlines = @('HCP1 RTC: initial slow line maneuvering'),
    [string[]]$SourceCatalogs    = @('Verifizierung_VirtuellerFuhrpark - Inbetriebnahme_HCP1'),
    [string[]]$ManeuverPaths,
    [string[]]$ManeuverCodes     = @('FMT HCP1 RTC 0101 IBNSLM'),
    [string]$TemplatePath,
    [string]$OutputPath
)

# ============================================================
# STEP 1: Run the ViMP execution in MATLAB, wait for it to exit
# ============================================================

Add-Content -Path "C:\ViMP\ViMP26052910002021bW64\ProjectsSE\991C2S_SEO390\ViMP_STOPREQUEST.vimp" -Value "Stop ViMP"

Write-Host "Starting configuration generation..." -ForegroundColor Cyan
Write-Host "SCRIPT VERSION: FIXED-v3-RootAwarePaths" -ForegroundColor Magenta

$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
if ((Split-Path -Leaf $scriptRoot) -ieq 'backup_powershell') {
    $scriptRoot = Split-Path -Parent $scriptRoot
}

function Resolve-ExistingPath {
    param([string[]]$Candidates)
    foreach ($candidate in $Candidates) {
        if (-not [string]::IsNullOrWhiteSpace($candidate) -and (Test-Path -LiteralPath $candidate)) {
            return $candidate
        }
    }
    return $Candidates[0]
}

if ([string]::IsNullOrWhiteSpace($TemplatePath)) {
    $TemplatePath = 'C:\ViMP\ViMP26052910002021bW64\ProjectsSE\ViMP.cfg'
}
# Always write output to the standard location.
$OutputPath = 'C:\ViMP\ViMP26052910002021bW64\ProjectsSE\991C2S_SEO390\ViMP.cfg'
if ($null -eq $ManeuverPaths -or $ManeuverPaths.Count -eq 0) {
    # Auto-discover all maneuver paths by recursive search through installation root.
    $searchRoot = Resolve-ExistingPath -Candidates @(
        $scriptRoot,
        'C:\ViMP\ViMP26052910002021bW64'
    )
    
    $discoveredPaths = @()
    $candidateDirs = @('SimEnv_EXPORTED\driver\par\maneuver', 'ProjectsSE\*\Maneuver', 'Maneuver') | ForEach-Object {
        $pattern = Join-Path $searchRoot $_
        Get-Item -LiteralPath (Split-Path -Parent $pattern) -ErrorAction SilentlyContinue | Get-ChildItem -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -like (Split-Path -Leaf $pattern) }
    }
    
    if ($null -ne $candidateDirs) {
        $discoveredPaths = @($candidateDirs | ForEach-Object { $_.FullName } | Select-Object -Unique)
    }
    
    if ($discoveredPaths.Count -eq 0) {
        # Fallback to known primary path.
        $discoveredPaths = @(
            (Resolve-ExistingPath -Candidates @(
                (Join-Path $scriptRoot 'SimEnv_EXPORTED\driver\par\maneuver'),
                'C:\ViMP\ViMP26052910002021bW64\SimEnv_EXPORTED\driver\par\maneuver'
            ))
        )
    }
    
    $ManeuverPaths = @($discoveredPaths)
}

foreach ($path in $ManeuverPaths) {
    if (-not (Test-Path -LiteralPath $path)) {
        Write-Warning "Configured ManeuverPath does not exist on this machine: $path"
    }
}

if (-not (Test-Path -Path $TemplatePath)) {
    Write-Error "Template file not found at path: $TemplatePath"
    return
}

# Derive primary length from ManeuverCodes.
$n = $ManeuverCodes.Count
if ($n -eq 0) {
    Write-Error "At least one ManeuverCode is required."
    return
}

# Auto-expand single-value arrays to match maneuver count (except ManeuverPaths which applies to all).
if ($ManeuverHeadlines.Count -eq 1 -and $n -gt 1) {
    $ManeuverHeadlines = @($ManeuverHeadlines[0]) * $n
}
if ($SourceCatalogs.Count -eq 1 -and $n -gt 1) {
    $SourceCatalogs = @($SourceCatalogs[0]) * $n
}
# ManeuverPaths is shared across all maneuvers (all in one cfg field).

if ($ManeuverHeadlines.Count -ne $n -or $SourceCatalogs.Count -ne $n) {
    Write-Error "ManeuverHeadlines ($($ManeuverHeadlines.Count)), SourceCatalogs ($($SourceCatalogs.Count)), and ManeuverCodes ($n) must all be the same length (or pass a single SourceCatalog/Headline value to repeat). ManeuverPaths is shared across all maneuvers."
    return
}

$CfgContent = Get-Content -Raw -Path $TemplatePath -Encoding UTF8

function Replace-Block {
    param(
        [string]$Text,
        [string]$Pattern,
        [string]$Replacement,
        [System.Text.RegularExpressions.RegexOptions]$Options = [System.Text.RegularExpressions.RegexOptions]::Singleline
    )
    $evaluator = { param($m) $Replacement }
    return [System.Text.RegularExpressions.Regex]::Replace($Text, $Pattern, $evaluator, $Options)
}

$CfgContent = Replace-Block -Text $CfgContent -Pattern "(AsmblyName\s+=\s+')[^']*(')" -Replacement "AsmblyName        = '$NewVehicleAssembly'"
$CfgContent = Replace-Block -Text $CfgContent -Pattern "(ARCmatlabVer\s+=\s+')[^']*(')" -Replacement "ARCmatlabVer         = '$NewMatlabVersion'"
$CfgContent = Replace-Block -Text $CfgContent -Pattern "SaveReport\s+=\s+\d+" -Replacement "SaveReport           = $SaveReportValue"

$lbLines = for ($i = 0; $i -lt $n; $i++) {
    if ($i -lt $n - 1) { "`t'$($ManeuverHeadlines[$i])' ; >>>" } else { "`t'$($ManeuverHeadlines[$i])'}" }
}
$NewLbBlock = @"
LbString          = { >>>
	'=====================MANEUVER====================' ; >>>
$($lbLines -join "`n")
"@
$CfgContent = Replace-Block -Text $CfgContent -Pattern "LbString\s+=\s+\{ >>>\s*\r?\n\t'=====================MANEUVER====================' ; >>>\r?\n.*?\}" -Replacement $NewLbBlock

$optBlocks = for ($i = 0; $i -lt $n; $i++) {
@"
          `$`$`$`$`$Opt_$($i + 1) !
               OptHeadline= '$($ManeuverHeadlines[$i])'
               PostFcnManCode= '$($ManeuverCodes[$i])'
          `$`$`$`$`$! end of Opt_$($i + 1)
"@
}
$NewOptStruct = @"
      `$`$`$`$ManOptStruct !
$($optBlocks -join "`n")
      `$`$`$`$! end of ManOptStruct
"@
$CfgContent = Replace-Block -Text $CfgContent -Pattern '\$\$\$\$ManOptStruct !.*?\$\$\$\$! end of ManOptStruct' -Replacement $NewOptStruct.Trim("`r", "`n")

$NewSourceCatalog = "SourceCatalog     = {" + (($SourceCatalogs | ForEach-Object { "'$_'" }) -join " ") + "}"
$NewManeuverPath  = "ManeuverPath      = {'_FMT_CSC\FMT_CSC_XXX_0001_SLM' '_FMT_CSC\FMT_CSC_XXX_0001_SRS' '_FMT_CSC\FMT_CSC_XXX_0001_SRS'}"
$NewManeuverCode  = "ManeuverCode      = {" + (($ManeuverCodes  | ForEach-Object { "'$_'" }) -join " ") + "}"

$CfgContent = Replace-Block -Text $CfgContent -Pattern "SourceCatalog\s+=\s+\{.*?\}" -Replacement $NewSourceCatalog
$CfgContent = Replace-Block -Text $CfgContent -Pattern "ManeuverPath\s+=\s+\{.*?\}"  -Replacement $NewManeuverPath
$CfgContent = Replace-Block -Text $CfgContent -Pattern "ManeuverCode\s+=\s+\{.*?\}"  -Replacement $NewManeuverCode

$msLines = for ($i = 0; $i -lt $n; $i++) {
    if ($i -lt $n - 1) { "`t'$($ManeuverHeadlines[$i])' ; >>>" } else { "`t'$($ManeuverHeadlines[$i])'}" }
}
$NewManeuverString = @"
ManeuverString    = { >>>
$($msLines -join "`n")
"@
$CfgContent = Replace-Block -Text $CfgContent -Pattern "ManeuverString\s+=\s+\{ >>>\r?\n.*?\}" -Replacement $NewManeuverString

$OutputDir = Split-Path -Parent $OutputPath
if ($OutputDir -and -not (Test-Path -Path $OutputDir)) {
    New-Item -ItemType Directory -Force -Path $OutputDir | Out-Null
}
$CfgContent = $CfgContent -replace "`r`n", "`n" -replace "`n", "`r`n"
$Utf8NoBom = New-Object System.Text.UTF8Encoding($false)
[System.IO.File]::WriteAllText($OutputPath, $CfgContent, $Utf8NoBom)

Write-Host "New configuration file successfully generated at: $OutputPath" -ForegroundColor Green

$verify = Get-Content -Raw -Path $OutputPath -Encoding UTF8
if ($verify -match "ManeuverPath\s+=\s+\{'[A-Za-z]:[^'\\]") {
    Write-Warning "ManeuverPath may be missing backslashes -- please inspect manually."
} else {
    Write-Host "Verification passed: ManeuverPath backslashes intact." -ForegroundColor Green
}
