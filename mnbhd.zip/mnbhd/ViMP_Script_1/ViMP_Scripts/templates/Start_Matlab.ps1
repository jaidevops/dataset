﻿$MatlabExe = "C:\Program Files\MATLAB\R2021b\bin\matlab.exe"
$MatlabCommand = "ViMPguiAPI('GUI',{'open'});ViMPguiAPI('SIM',{'startvimp'});ViMPguiAPI('GUI',{'close'});exit force"
 
Start-Process -FilePath $MatlabExe `
  -ArgumentList "-nodesktop -r `"$MatlabCommand`"" `
  -RedirectStandardOutput "C:\ViMP\run_stdout.log" `
  -RedirectStandardError  "C:\ViMP\run_stderr.log" `
  -Wait