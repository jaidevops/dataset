﻿<#
.SYNOPSIS
    Archives ViMP output: creates an "archive" subfolder inside the ViMP project
    directory (if missing), then moves all "ViMP_*" subdirectories and the
    "ViMP.cfg" file into it.

.DESCRIPTION
    Source and archive both live under the same parent path:
        C:\ViMP\ViMP26052910002021bW64\ProjectsSE\991C2S_SEO390
    The archive directory is a SUBFOLDER of that path (default name: "archive"),
    not a separate location. Layout after running:

        991C2S_SEO390\
            ViMP.cfg               <- gets moved
            ViMP_20260101_...\     <- gets moved (directory)
            ViMP_20260102_...\     <- gets moved (directory)
            archive\                <- created if missing
                ViMP.cfg
                ViMP_20260101_...\
                ViMP_20260102_...\

    1. Creates <SourcePath>\<ArchiveFolderName> if it doesn't already exist.
    2. Moves every DIRECTORY matching "ViMP_*" from SourcePath into the archive.
       The archive folder itself is excluded, so re-running the script is safe.
    3. Moves "ViMP.cfg" from SourcePath into the archive.

    Both move steps use -Force so an existing item of the same name in the
    archive gets overwritten rather than throwing an error. Missing source
    items are reported as warnings, not fatal errors, so the script completes
    even if one of the two patterns has nothing to move.

.PARAMETER SourcePath
    Directory containing the ViMP_* subdirectories and ViMP.cfg.
    Defaults to C:\ViMP\ViMP26052910002021bW64\ProjectsSE\991C2S_SEO390.

.PARAMETER ArchiveFolderName
    Name of the archive subfolder to create/use inside SourcePath. Default: "archive".

.EXAMPLE
    .\Archive-VimpFiles.ps1

.EXAMPLE
    .\Archive-VimpFiles.ps1 -SourcePath "C:\ViMP\ViMP26052910002021bW64\ProjectsSE\991C2S_SEO390" -ArchiveFolderName "archive"
#>
param (
    [string]$SourcePath         = "C:\ViMP\ViMP26052910002021bW64\ProjectsSE\991C2S_SEO390",
    [string]$ArchiveFolderName  = "archive"
)

Write-Host "Starting ViMP archive step..." -ForegroundColor Cyan

if (-not (Test-Path -Path $SourcePath)) {
    Write-Error "Source path not found: $SourcePath"
    return
}

$ArchivePath = Join-Path -Path $SourcePath -ChildPath $ArchiveFolderName

# --- 1. Create archive directory (inside SourcePath) if it doesn't exist ----
if (-not (Test-Path -Path $ArchivePath)) {
    try {
        New-Item -ItemType Directory -Path $ArchivePath -Force | Out-Null
        Write-Host "Created archive directory: $ArchivePath" -ForegroundColor Green
    }
    catch {
        Write-Error "Failed to create archive directory '$ArchivePath': $_"
        return
    }
}
else {
    Write-Host "Archive directory already exists: $ArchivePath" -ForegroundColor Yellow
}

# --- 2. Move ViMP_* DIRECTORIES into the archive -----------------------------
# Exclude the archive folder itself so re-running the script is idempotent.
$vimpDirs = Get-ChildItem -Path $SourcePath -Filter "ViMP_*" -Directory -ErrorAction SilentlyContinue |
            Where-Object { $_.FullName -ne $ArchivePath }

if ($vimpDirs) {
    foreach ($dir in $vimpDirs) {
        $destination = Join-Path -Path $ArchivePath -ChildPath $dir.Name
        try {
            if (Test-Path -Path $destination) {
                Remove-Item -Path $destination -Recurse -Force
            }
            Move-Item -Path $dir.FullName -Destination $ArchivePath -Force
            Write-Host "Moved: $($dir.Name) -> $ArchivePath" -ForegroundColor Green
        }
        catch {
            Write-Warning "Failed to move '$($dir.Name)': $_"
        }
    }
}
else {
    Write-Warning "No directories matching 'ViMP_*' found in '$SourcePath'."
}

# --- 3. Move ViMP.cfg into the archive ---------------------------------------
$cfgFile = Join-Path -Path $SourcePath -ChildPath "ViMP.cfg"

if (Test-Path -Path $cfgFile -PathType Leaf) {
    try {
        Move-Item -Path $cfgFile -Destination $ArchivePath -Force
        Write-Host "Moved: ViMP.cfg -> $ArchivePath" -ForegroundColor Green
    }
    catch {
        Write-Warning "Failed to move 'ViMP.cfg': $_"
    }
}
else {
    Write-Warning "'ViMP.cfg' not found in '$SourcePath'."
}

# --- 4. Move ViMP.status into the archive ---------------------------------------
$statusFile = Join-Path -Path $SourcePath -ChildPath "ViMP.status"

if (Test-Path -Path $statusFile -PathType Leaf) {
    try {
        Move-Item -Path $statusFile -Destination $ArchivePath -Force
        Write-Host "Moved: ViMP.status -> $ArchivePath" -ForegroundColor Green
    }
    catch {
        Write-Warning "Failed to move 'ViMP.status': $_"
    }
}
else {
    Write-Warning "'ViMP.status' not found in '$SourcePath'."
}

Write-Host "Archive step complete." -ForegroundColor Cyan

