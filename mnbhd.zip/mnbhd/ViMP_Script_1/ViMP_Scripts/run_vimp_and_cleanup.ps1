# ============================================================
# STEP 1: Run the ViMP execution in MATLAB, wait for it to exit
# ============================================================

Add-Content -Path "C:\ViMP\ViMP26052910002021bW64\ProjectsSE\991C2S_SEO390\ViMP_STOPREQUEST.vimp" -Value "Stop ViMP"

# ============================================================
# STEP 1: Run the ViMP execution in MATLAB, wait for it to exit
# ============================================================
$MatlabExe     = "C:\Program Files\MATLAB\R2021b\bin\matlab.exe"
$MatlabCommand = "ViMPguiAPI('GUI',{'open'});ViMPguiAPI('SIM',{'startvimp'});ViMPguiAPI('GUI',{'close'});exit force"
$LogDir        = "C:\ViMP"
$PostScript    = "C:\ViMP_Script_1\ViMP_Scripts\post_ViMP_execution.ps1"

if (-not (Test-Path $LogDir)) { New-Item -ItemType Directory -Path $LogDir | Out-Null }

Write-Output "STEP 1: Starting ViMP execution in MATLAB..."
Start-Process -FilePath $MatlabExe `
  -ArgumentList "-nodesktop -r `"$MatlabCommand`"" `
  -RedirectStandardOutput "$LogDir\run_stdout.log" `
  -RedirectStandardError  "$LogDir\run_stderr.log" `
  -Wait

Write-Output "STEP 1 complete: MATLAB process has exited."

# ============================================================
# STEP 2: Run post cleanup PowerShell script
# ============================================================
Write-Output "STEP 2: Running post execution cleanup script..."
& $PostScript -DebugLookup

Write-Output "All steps completed."