param(
    [Alias('Codes')]
    [string[]]$ManeuverCodes,
    [Alias('Headlines')]
    [string[]]$ManeuverHeadlines,
    [Alias('ManeuverXml','XmlCatalog','CatalogXml')]
    [string]$ManeuverCatalogXmlPath,
    [switch]$DebugLookup,
    [string]$VmcRoot,
    [string]$SourceCatalog = 'Verifizierung_VirtuellerFuhrpark - Inbetriebnahme_HCP1',
    [string]$ManeuverPath,
    [string]$TemplatePath,
    [string]$OutputPath
)

$ScriptVersion = 'Initial_cfg_setup.ps1 v2026-07-17.2'
Write-Host "Starting initial cfg setup..." -ForegroundColor Cyan
Write-Host "SCRIPT VERSION: $ScriptVersion" -ForegroundColor Magenta

$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
if ((Split-Path -Leaf $scriptRoot) -ieq 'backup_powershell') {
    $scriptRoot = Split-Path -Parent $scriptRoot
}
$remoteScriptRoot = 'C:\ViMP_Script_1\ViMP_Scripts'
$remoteVimpRoot = 'C:\ViMP'
$remoteInstallRoot = 'C:\ViMP\ViMP26052910002021bW64'
$vewBasePath = 'C:\Users\iya2kor\Desktop\VHUB\VEW\ViMP26052910002021bW64'

function Resolve-InstallRoot {
    param([string]$ScriptRootPath)

    $cwd = (Get-Location).Path
    $candidateRoots = @(
        $ScriptRootPath,
        (Split-Path -Parent $ScriptRootPath),
        $cwd,
        (Split-Path -Parent $cwd),
        $remoteInstallRoot,
        $vewBasePath,
        'C:\ViMP\ViMP26052910002021bW64'
    ) | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | Select-Object -Unique

    foreach ($root in $candidateRoots) {
        if ((Test-Path -LiteralPath (Join-Path $root 'SimEnv_EXPORTED')) -and (Test-Path -LiteralPath (Join-Path $root 'ProjectsSE'))) {
            return $root
        }
    }

    return $ScriptRootPath
}

$installRoot = Resolve-InstallRoot -ScriptRootPath $scriptRoot

$hasExplicitManeuverCatalogXmlPath = $PSBoundParameters.ContainsKey('ManeuverCatalogXmlPath') -and -not [string]::IsNullOrWhiteSpace($ManeuverCatalogXmlPath)

function Resolve-ExistingPath {
    param([string[]]$Candidates)
    foreach ($candidate in $Candidates) {
        if (-not [string]::IsNullOrWhiteSpace($candidate) -and (Test-Path -LiteralPath $candidate)) {
            return $candidate
        }
    }
    return $Candidates[0]
}

function Resolve-ManeuverCatalogXmlPath {
    param([string]$RootPath)

    $staticCandidates = @(
        (Join-Path $RootPath 'maneuvers_test.xml'),
        (Join-Path $RootPath 'ProjectsSE\maneuvers_test.xml'),
        (Join-Path $RootPath 'Maneuvers.xml'),
        (Join-Path $RootPath 'ViMP_Maneuvers.xml'),
        (Join-Path $RootPath 'ViMP.maneuvers.xml'),
        (Join-Path $RootPath 'ProjectsSE\Maneuvers.xml'),
        (Join-Path $RootPath 'ProjectsSE\ViMP_Maneuvers.xml'),
        (Join-Path $RootPath 'ProjectsSE\ViMP.maneuvers.xml')
    )

    $resolvedStatic = Resolve-ExistingPath -Candidates $staticCandidates
    if (-not [string]::IsNullOrWhiteSpace($resolvedStatic) -and (Test-Path -LiteralPath $resolvedStatic)) {
        return $resolvedStatic
    }

    $searchDirs = @($RootPath, (Join-Path $RootPath 'ProjectsSE')) | Select-Object -Unique
    foreach ($dir in $searchDirs) {
        if (-not (Test-Path -LiteralPath $dir)) { continue }

        $match = Get-ChildItem -LiteralPath $dir -File -Filter '*.xml' -ErrorAction SilentlyContinue |
            Where-Object {
                $_.Name -match '(?i)maneuver|vimp' -and
                ((Get-Content -LiteralPath $_.FullName -TotalCount 12 -ErrorAction SilentlyContinue) -join "`n") -match '<ViMP>|<Maneuvers>'
            } |
            Select-Object -First 1

        if ($match) {
            return $match.FullName
        }
    }

    return $staticCandidates[0]
}

function Get-ManeuverCatalogXmlCandidates {
    param([string]$RootPath)

    $candidates = @()
    $candidates += @(
        (Join-Path $RootPath 'maneuvers_test.xml'),
        (Join-Path $RootPath 'ProjectsSE\maneuvers_test.xml'),
        (Join-Path $RootPath 'Maneuvers.xml'),
        (Join-Path $RootPath 'ViMP_Maneuvers.xml'),
        (Join-Path $RootPath 'ViMP.maneuvers.xml'),
        (Join-Path $RootPath 'ProjectsSE\Maneuvers.xml'),
        (Join-Path $RootPath 'ProjectsSE\ViMP_Maneuvers.xml'),
        (Join-Path $RootPath 'ProjectsSE\ViMP.maneuvers.xml')
    )

    $searchDirs = @($RootPath, (Join-Path $RootPath 'ProjectsSE')) | Select-Object -Unique
    foreach ($dir in $searchDirs) {
        if (-not (Test-Path -LiteralPath $dir)) { continue }

        $hits = Get-ChildItem -LiteralPath $dir -File -Filter '*.xml' -ErrorAction SilentlyContinue |
            Where-Object {
                $_.Name -match '(?i)maneuver|vimp' -and
                ((Get-Content -LiteralPath $_.FullName -TotalCount 24 -ErrorAction SilentlyContinue) -join "`n") -match '<ViMP>|<Maneuvers>'
            }

        if ($hits) {
            $candidates += @($hits.FullName)
        }
    }

    return @($candidates | Where-Object { -not [string]::IsNullOrWhiteSpace($_) -and (Test-Path -LiteralPath $_) } | Select-Object -Unique)
}

if ([string]::IsNullOrWhiteSpace($VmcRoot)) {
    $VmcRoot = Resolve-ExistingPath -Candidates @(
        (Join-Path $remoteInstallRoot 'SimEnv_EXPORTED\util\VeDA\config\maneuvers'),
        (Join-Path $installRoot 'SimEnv_EXPORTED\util\VeDA\config\maneuvers'),
        (Join-Path $scriptRoot 'SimEnv_EXPORTED\util\VeDA\config\maneuvers'),
        'C:\ViMP\ViMP26052910002021bW64\SimEnv_EXPORTED\util\VeDA\config\maneuvers'
    )
}
if ([string]::IsNullOrWhiteSpace($ManeuverPath)) {
    # Auto-discover all maneuver paths by recursive search through installation root.
    $cwdPath = (Get-Location).Path
    $searchRoot = Resolve-ExistingPath -Candidates @(
        $cwdPath,
        $installRoot,
        $scriptRoot,
        $remoteInstallRoot,
        'C:\ViMP\ViMP26052910002021bW64'
    )
    
    $discoveredPaths = @()
    $candidateDirs = @('SimEnv_EXPORTED\driver\par\maneuver', 'ProjectsSE\*\Maneuver', 'Maneuver') | ForEach-Object {
        $pattern = Join-Path $searchRoot $_
        Get-Item -LiteralPath (Split-Path -Parent $pattern) -ErrorAction SilentlyContinue | Get-ChildItem -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -like (Split-Path -Leaf $pattern) }
    }
    
    if ($null -ne $candidateDirs) {
        $discoveredPaths = @($candidateDirs | ForEach-Object { $_.FullName } | Select-Object -Unique)
    }
    
    if ($discoveredPaths.Count -eq 0) {
        # Fallback to known primary path.
        $ManeuverPath = Resolve-ExistingPath -Candidates @(
            (Join-Path $cwdPath 'SimEnv_EXPORTED\driver\par\maneuver'),
            (Join-Path $installRoot 'SimEnv_EXPORTED\driver\par\maneuver'),
            (Join-Path $remoteInstallRoot 'SimEnv_EXPORTED\driver\par\maneuver'),
            (Join-Path $scriptRoot 'SimEnv_EXPORTED\driver\par\maneuver'),
            'C:\ViMP\ViMP26052910002021bW64\SimEnv_EXPORTED\driver\par\maneuver'
        )
    } else {
        $ManeuverPath = ($discoveredPaths -join ';')
    }
}
if ([string]::IsNullOrWhiteSpace($TemplatePath)) {
    $TemplatePath = Resolve-ExistingPath -Candidates @(
        (Join-Path $remoteVimpRoot 'ViMP.cfg'),
        (Join-Path $remoteInstallRoot 'ProjectsSE\ViMP.cfg'),
        (Join-Path $installRoot 'ProjectsSE\ViMP.cfg'),
        (Join-Path $scriptRoot 'ProjectsSE\ViMP.cfg'),
        (Join-Path $vewBasePath 'ProjectsSE\ViMP.cfg'),
        'C:\ViMP\ViMP26052910002021bW64\ProjectsSE\ViMP.cfg'
    )

    if (-not (Test-Path -LiteralPath $TemplatePath)) {
        $templateSearchRoots = @($installRoot, $scriptRoot, $remoteInstallRoot, $vewBasePath) | Select-Object -Unique
        foreach ($root in $templateSearchRoots) {
            if (-not (Test-Path -LiteralPath $root)) { continue }
            $projectsSeRoot = Join-Path $root 'ProjectsSE'
            if (-not (Test-Path -LiteralPath $projectsSeRoot)) { continue }

            $templateHit = Get-ChildItem -LiteralPath $projectsSeRoot -Filter 'ViMP.cfg' -File -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
            if ($templateHit) {
                $TemplatePath = $templateHit.FullName
                break
            }
        }
    }
}
if ([string]::IsNullOrWhiteSpace($ManeuverCatalogXmlPath)) {
    $ManeuverCatalogXmlPath = Resolve-ExistingPath -Candidates @(
        (Join-Path $remoteScriptRoot 'maneuvers_test.xml'),
        (Join-Path $scriptRoot 'maneuvers_test.xml'),
        (Resolve-ManeuverCatalogXmlPath -RootPath $scriptRoot),
        (Resolve-ManeuverCatalogXmlPath -RootPath $installRoot)
    )
}
if ([string]::IsNullOrWhiteSpace($OutputPath)) {
    $OutputPath = Resolve-ExistingPath -Candidates @(
        (Join-Path $remoteInstallRoot 'ProjectsSE\991C2S_SEO390\ViMP.cfg'),
        (Join-Path $installRoot 'ProjectsSE\991C2S_SEO390\ViMP.cfg'),
        (Join-Path $scriptRoot 'ProjectsSE\991C2S_SEO390\ViMP.cfg'),
        'C:\ViMP\ViMP26052910002021bW64\ProjectsSE\991C2S_SEO390\ViMP.cfg'
    )
}

# Allow plain trailing args as maneuver codes, e.g. .\Initial_cfg_setup.ps1 'FMT ...' 'FMT ...'
if (($null -eq $ManeuverCodes -or $ManeuverCodes.Count -eq 0) -and $args.Count -gt 0) {
    $ManeuverCodes = @($args)
}

if (($null -eq $ManeuverCodes -or $ManeuverCodes.Count -eq 0) -and ($null -eq $ManeuverHeadlines -or $ManeuverHeadlines.Count -eq 0)) {
    Write-Host "Provide at least one of: -ManeuverCodes or -ManeuverHeadlines" -ForegroundColor Yellow
    Write-Host "Examples:" -ForegroundColor Yellow
    Write-Host "  .\Initial_cfg_setup.ps1 -ManeuverCodes 'FMT PSM HOLD 0008 SLBSA','FMT PSM HOLD 0009 SLBS'"
    Write-Host "  .\Initial_cfg_setup.ps1 -ManeuverHeadlines 'HCP1 RTC: initial slow line maneuvering'"
    Write-Host "  .\Initial_cfg_setup.ps1 'FMT PSM HOLD 0008 SLBSA' 'FMT PSM HOLD 0009 SLBS'"
    exit 1
}

if (-not (Test-Path -LiteralPath $VmcRoot)) {
    Write-Warning "VmcRoot not found: $VmcRoot. Continuing with CFG/XML lookup sources."
}

function Normalize-Text([string]$s) {
    if ($null -eq $s) { return '' }
    $norm = $s.Replace('_', ' ')
    $norm = ($norm -replace '\s+', ' ').Trim()
    return $norm.ToUpperInvariant()
}

function Get-ComparableHeadline([string]$s) {
    $norm = Normalize-Text $s
    if ([string]::IsNullOrWhiteSpace($norm)) { return '' }

    # Strip variant/detail suffixes often carried in option labels.
    $norm = $norm -replace '\([^\)]*\)', ' '
    $norm = $norm -replace '\[[^\]]*\]', ' '
    $norm = $norm -replace '[^A-Z0-9\s]', ' '
    $norm = ($norm -replace '\s+', ' ').Trim()
    return $norm
}

function Get-HeadlineTail([string]$s) {
    $norm = Normalize-Text $s
    if ([string]::IsNullOrWhiteSpace($norm)) { return '' }

    $tokens = @($norm -split '\s+')
    $numIdx = -1
    for ($i = 0; $i -lt $tokens.Count; $i++) {
        if ($tokens[$i] -match '^\d{4}$') {
            $numIdx = $i
            break
        }
    }

    if ($numIdx -ge 0 -and $numIdx -lt ($tokens.Count - 1)) {
        return (($tokens[($numIdx + 1)..($tokens.Count - 1)]) -join ' ').Trim()
    }

    return ''
}

function Get-ManeuverIndex([string]$s) {
    $norm = Normalize-Text $s
    if ([string]::IsNullOrWhiteSpace($norm)) { return $null }

    $tokens = @($norm -split '\s+')
    foreach ($token in $tokens) {
        if ($token -match '^\d{4}$') {
            return [int]$token
        }
    }

    return $null
}

function Get-ManeuverCodeStemCandidates([string]$Code) {
    if ([string]::IsNullOrWhiteSpace($Code)) { return @() }

    $normalized = Normalize-Text $Code
    $stemCandidates = @(
        $Code.Trim(),
        ($Code.Trim() -replace '\s+', '_'),
        ($Code.Trim() -replace '[:\(\)\[\],]', '' -replace '\s+', '_'),
        $normalized,
        ($normalized -replace ' ', '_')
    )

    return @($stemCandidates | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | Select-Object -Unique)
}

function Test-ValidLookupPair($Pair) {
    if ($null -eq $Pair) { return $false }
    if ([string]::IsNullOrWhiteSpace($Pair.Code) -or [string]::IsNullOrWhiteSpace($Pair.Headline)) { return $false }

    $codeNorm = Normalize-Text $Pair.Code
    $headlineNorm = Normalize-Text $Pair.Headline

    if ($codeNorm.Length -lt 4 -or $headlineNorm.Length -lt 4) { return $false }
    if ($codeNorm -eq $headlineNorm) { return $false }
    if ($Pair.PSObject.Properties['Source'] -and $Pair.Source -eq 'XML') {
        return $true
    }
    if ($codeNorm -notmatch 'FMT|FUPA|HCP1|PSM|PPE|CSC|RTC|ADC|DSI|VDSO|SRC|AITV|INB') { return $false }
    return $true
}

function Write-DebugLookupMessage([string]$Message) {
    if ($DebugLookup) {
        Write-Host $Message -ForegroundColor DarkCyan
    }
}

function Convert-XmlManeuverTagToCode([string]$TagName) {
    if ([string]::IsNullOrWhiteSpace($TagName)) { return '' }

    $base = ($TagName -replace '(?i)_OPT\d+$', '')
    $norm = Normalize-Text $base
    if ($norm -match '^FMT\s+') {
        return $norm
    }

    # Keep non-FMT XML maneuver keys as their original symbolic identifiers.
    return $base
}

function Get-XmlPairs([string]$XmlPath) {
    if ([string]::IsNullOrWhiteSpace($XmlPath) -or -not (Test-Path -LiteralPath $XmlPath)) {
        return @()
    }

    try {
        [xml]$xmlDoc = Get-Content -LiteralPath $XmlPath -Raw -Encoding UTF8
    }
    catch {
        Write-Warning "Failed to parse XML catalog '$XmlPath': $($_.Exception.Message)"
        return @()
    }

    $pairs = @()
    $nodes = $xmlDoc.SelectNodes('//*')
    foreach ($node in $nodes) {
        if ($null -eq $node) { continue }
        if ($node.ChildNodes.Count -gt 1) { continue }
        if ($node.ChildNodes.Count -eq 1 -and $node.FirstChild.NodeType -ne [System.Xml.XmlNodeType]::Text) { continue }

        $headline = Normalize-Text $node.InnerText
        if ([string]::IsNullOrWhiteSpace($headline)) { continue }

        $code = Convert-XmlManeuverTagToCode $node.Name
        if ([string]::IsNullOrWhiteSpace($code)) { continue }

        $pairs += [PSCustomObject]@{
            Code = $code
            Headline = $headline
            Source = 'XML'
        }
    }

    return @($pairs | Where-Object { Test-ValidLookupPair $_ } | Sort-Object Code, Headline -Unique)
}

# Built-in fallback mappings keep common maneuvers resolvable even when VMC/CFG
# lookup sources are unavailable in a standalone script deployment.
$builtInPairs = @(
    [PSCustomObject]@{
        Code = 'FMT HCP1 RTC 0101 IBNSLM'
        Headline = 'HCP1 RTC: initial slow line maneuvering'
    }
) | Where-Object { Test-ValidLookupPair $_ }

# Build lookup table from OptHeadline <-> PostFcnManCode.
$vmcPairs = @()
if (-not [string]::IsNullOrWhiteSpace($VmcRoot) -and (Test-Path -LiteralPath $VmcRoot)) {
    $vmcPairs = Get-ChildItem -Path $VmcRoot -Recurse -Filter '*.vmc' -File | ForEach-Object {
        $txt = Get-Content -LiteralPath $_.FullName -Raw
        [regex]::Matches($txt, "(?s)OptHeadline\s*=\s*'(?<h>[^']+)'.*?PostFcnManCode\s*=\s*'(?<c>[^']+)'") |
            ForEach-Object {
                [PSCustomObject]@{
                    Code = $_.Groups['c'].Value
                    Headline = $_.Groups['h'].Value
                }
            }
    } | Where-Object { Test-ValidLookupPair $_ } | Sort-Object Code, Headline -Unique
}

function Get-CfgPairs([string]$CfgPath) {
    if (-not (Test-Path -LiteralPath $CfgPath)) { return @() }

    $cfgText = Get-Content -LiteralPath $CfgPath -Raw -Encoding UTF8
    $pairs = @()

    $optPairs = [regex]::Matches(
        $cfgText,
        "(?s)OptHeadline\s*=\s*'(?<h>[^']+)'.*?PostFcnManCode\s*=\s*'(?<c>[^']+)'"
    ) | ForEach-Object {
        [PSCustomObject]@{
            Code = $_.Groups['c'].Value
            Headline = $_.Groups['h'].Value
        }
    }

    if ($optPairs) {
        $pairs += $optPairs
    }

    # Fallback mapping from ManeuverCode/ManeuverString lists.
    $codeMatch = [regex]::Match($cfgText, '(?s)ManeuverCode\s*=\s*\{(?<body>.*?)\}')
    $stringMatch = [regex]::Match($cfgText, '(?s)ManeuverString\s*=\s*\{(?<body>.*?)\}')
    if ($codeMatch.Success -and $stringMatch.Success) {
        $codes = [regex]::Matches($codeMatch.Groups['body'].Value, "'([^']*)'") | ForEach-Object { $_.Groups[1].Value }
        $headlines = [regex]::Matches($stringMatch.Groups['body'].Value, "'([^']*)'") | ForEach-Object { $_.Groups[1].Value }
        $count = [Math]::Min($codes.Count, $headlines.Count)
        for ($i = 0; $i -lt $count; $i++) {
            $pairs += [PSCustomObject]@{
                Code = $codes[$i]
                Headline = $headlines[$i]
            }
        }
    }

    return @($pairs | Where-Object { Test-ValidLookupPair $_ } | Sort-Object Code, Headline -Unique)
}

$projectFallbackCfgPath = Join-Path $installRoot 'ProjectsSE\ViMP.cfg'
$vewFallbackCfgPath = Join-Path $vewBasePath 'ProjectsSE\ViMP.cfg'
$legacyFallbackCfgPath = 'C:\ViMP\ViMP26052910002021bW64\ProjectsSE\ViMP.cfg'
$cfgPaths = @($TemplatePath, $OutputPath, $projectFallbackCfgPath, $vewFallbackCfgPath, $legacyFallbackCfgPath) | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | Select-Object -Unique
$cfgPairs = @()
foreach ($cfgPath in $cfgPaths) {
    $cfgPairs += Get-CfgPairs -CfgPath $cfgPath
}
$cfgPairs = @($cfgPairs | Where-Object { Test-ValidLookupPair $_ } | Sort-Object Code, Headline -Unique)
$xmlCatalogPaths = @()
if ($hasExplicitManeuverCatalogXmlPath -and (Test-Path -LiteralPath $ManeuverCatalogXmlPath)) {
    $xmlCatalogPaths = @($ManeuverCatalogXmlPath)
} else {
    $xmlCatalogPaths = @(
        (Get-ManeuverCatalogXmlCandidates -RootPath $scriptRoot) +
        (Get-ManeuverCatalogXmlCandidates -RootPath $installRoot) +
        (Get-ManeuverCatalogXmlCandidates -RootPath $remoteScriptRoot)
    ) | Where-Object { -not [string]::IsNullOrWhiteSpace($_) -and (Test-Path -LiteralPath $_) } | Select-Object -Unique
    if ($xmlCatalogPaths.Count -eq 0 -and -not [string]::IsNullOrWhiteSpace($ManeuverCatalogXmlPath) -and (Test-Path -LiteralPath $ManeuverCatalogXmlPath)) {
        $xmlCatalogPaths = @($ManeuverCatalogXmlPath)
    }
}

$xmlPairs = @()
$xmlSourcesLoaded = @()
foreach ($xmlPath in $xmlCatalogPaths) {
    $pairsFromSource = Get-XmlPairs -XmlPath $xmlPath
    if ($pairsFromSource.Count -gt 0) {
        $xmlPairs += $pairsFromSource
        $xmlSourcesLoaded += "$xmlPath ($($pairsFromSource.Count))"
    }
}

$xmlPairs = @($xmlPairs | Where-Object { Test-ValidLookupPair $_ } | Sort-Object Code, Headline -Unique)
$lookupPairs = @($vmcPairs + $cfgPairs + $xmlPairs + $builtInPairs) | Where-Object { Test-ValidLookupPair $_ } | Sort-Object Code, Headline -Unique

Write-DebugLookupMessage "Lookup source VMC root: $VmcRoot"
foreach ($cfgPath in $cfgPaths) {
    Write-DebugLookupMessage "Lookup source CFG path: $cfgPath"
}
if ($xmlSourcesLoaded.Count -gt 0) {
    Write-DebugLookupMessage "Lookup source XML catalogs: $($xmlSourcesLoaded -join '; ')"
} else {
    Write-DebugLookupMessage "Lookup source XML catalog: $ManeuverCatalogXmlPath"
}
Write-DebugLookupMessage "Loaded VMC pairs: $($vmcPairs.Count)"
Write-DebugLookupMessage "Loaded CFG pairs: $($cfgPairs.Count)"
Write-DebugLookupMessage "Loaded XML pairs: $($xmlPairs.Count)"
Write-DebugLookupMessage "Loaded built-in fallback pairs: $($builtInPairs.Count)"
Write-DebugLookupMessage "Loaded total lookup pairs: $($lookupPairs.Count)"

if ($lookupPairs.Count -eq 0) {
    throw "No OptHeadline/PostFcnManCode mappings found in: $VmcRoot or $TemplatePath"
}

$resolvedCodes = @()
$resolvedHeadlines = @()

if ($ManeuverCodes -and $ManeuverCodes.Count -gt 0) {
    foreach ($code in $ManeuverCodes) {
        $resolvedCodes += $code
        $hit = $lookupPairs | Where-Object { (Normalize-Text $_.Code) -eq (Normalize-Text $code) } | Select-Object -First 1
        if ($hit) {
            Write-DebugLookupMessage "Resolved code '$code' to headline '$($hit.Headline)'"
            $resolvedHeadlines += $hit.Headline
        }
        else {
            # Fallback keeps cfg generation possible even if mapping is not in .vmc.
            Write-DebugLookupMessage "No headline mapping found for code '$code'; using code as headline fallback"
            $resolvedHeadlines += $code
        }
    }
}
else {
    foreach ($headline in $ManeuverHeadlines) {
        $hit = $null
        $headlineNorm = Normalize-Text $headline
        Write-DebugLookupMessage "Resolving headline '$headline' (normalized: '$headlineNorm')"
        $exactMatches = @($lookupPairs | Where-Object { (Normalize-Text $_.Headline) -eq $headlineNorm })
        if ($DebugLookup -and $exactMatches.Count -gt 0) {
            foreach ($match in $exactMatches) {
                Write-DebugLookupMessage "Exact match candidate: $($match.Headline) => $($match.Code)"
            }
        }
        if ($exactMatches.Count -gt 1) {
            # When multiple exact matches exist, prefer the code whose prefix (after "FMT ")
            # appears in the headline text.
            $scoreRanked = $exactMatches | ForEach-Object {
                $codePrefix = ($_.Code -split '\s+')[1..2] -join ' '  # Extract e.g. "FUPA INB" from "FMT FUPA INB 0001 SLM"
                $scoredMatch = $_
                $score = 0
                if ($headlineNorm -like "*$codePrefix*") {
                    $score += 10
                }
                [PSCustomObject]@{ Match = $scoredMatch; Score = $score }
            } | Sort-Object Score -Descending

            if ($scoreRanked[0].Score -gt $scoreRanked[1].Score) {
                $hit = $scoreRanked[0].Match
                Write-DebugLookupMessage "Resolved ambiguous exact match using code-prefix ranking: '$($hit.Code)'"
            } else {
                $options = ($exactMatches | ForEach-Object { "$($_.Headline) => $($_.Code)" }) -join '; '
                throw "Headline '$headline' matched multiple maneuver codes with equal priority. Be more specific. Matches: $options"
            }
        } elseif ($exactMatches.Count -eq 1) {
            $hit = $exactMatches | Select-Object -First 1
        }
        else {
            $comparableHeadlineNorm = Get-ComparableHeadline $headline
            if (-not [string]::IsNullOrWhiteSpace($comparableHeadlineNorm)) {
                $comparableMatches = @($lookupPairs | Where-Object {
                    (Get-ComparableHeadline $_.Headline) -eq $comparableHeadlineNorm
                })

                if ($DebugLookup -and $comparableMatches.Count -gt 0) {
                    foreach ($match in $comparableMatches) {
                        Write-DebugLookupMessage "Comparable match candidate: $($match.Headline) => $($match.Code)"
                    }
                }

                if ($comparableMatches.Count -eq 1) {
                    $hit = $comparableMatches[0]
                } elseif ($comparableMatches.Count -gt 1) {
                    $scoreRanked = $comparableMatches | ForEach-Object {
                        $codePrefix = ($_.Code -split '\s+')[1..2] -join ' '
                        $score = 0
                        if ($headlineNorm -like "*$codePrefix*") {
                            $score += 10
                        }

                        $candidateComparable = Get-ComparableHeadline $_.Headline
                        $distance = [Math]::Abs($candidateComparable.Length - $comparableHeadlineNorm.Length)

                        [PSCustomObject]@{
                            Match = $_
                            Score = $score
                            Distance = $distance
                        }
                    } | Sort-Object @{ Expression = 'Score'; Descending = $true }, @{ Expression = 'Distance'; Descending = $false }

                    if ($scoreRanked.Count -gt 1 -and ($scoreRanked[0].Score -gt $scoreRanked[1].Score -or $scoreRanked[0].Distance -lt $scoreRanked[1].Distance)) {
                        $hit = $scoreRanked[0].Match
                        Write-DebugLookupMessage "Resolved comparable headline match using ranking: '$($hit.Code)'"
                    }
                }
            }

            if ($hit) {
                # comparable fallback resolved this headline
            }
            else {
            $containsMatches = @($lookupPairs | Where-Object {
                $candidate = Normalize-Text $_.Headline
                $candidate -like "*$headlineNorm*" -or $headlineNorm -like "*$candidate*"
            })

            if ($DebugLookup -and $containsMatches.Count -gt 0) {
                foreach ($match in $containsMatches) {
                    Write-DebugLookupMessage "Partial match candidate: $($match.Headline) => $($match.Code)"
                }
            }

            if ($containsMatches.Count -gt 1) {
                # When multiple substring matches exist, prefer the code whose prefix appears in the headline.
                $scoreRanked = $containsMatches | ForEach-Object {
                    $codePrefix = ($_.Code -split '\s+')[1..2] -join ' '
                    $scoredMatch = $_
                    $score = 0
                    if ($headlineNorm -like "*$codePrefix*") {
                        $score += 10
                    }
                    if ((Normalize-Text $_.Headline) -like "*$headlineNorm*") {
                        $score += 1
                    }
                    [PSCustomObject]@{ Match = $scoredMatch; Score = $score }
                } | Sort-Object Score -Descending

                if ($scoreRanked.Count -gt 1 -and $scoreRanked[0].Score -gt $scoreRanked[1].Score) {
                    $hit = $scoreRanked[0].Match
                    Write-DebugLookupMessage "Resolved ambiguous substring match using code-prefix ranking: '$($hit.Code)'"
                } else {
                    $options = ($containsMatches | ForEach-Object { "$($_.Headline) => $($_.Code)" }) -join '; '
                    throw "Headline '$headline' partially matched multiple maneuver codes with equal priority. Be more specific. Matches: $options"
                }
            } elseif ($containsMatches.Count -eq 1) {
                $hit = $containsMatches | Select-Object -First 1
            }

            if (-not $hit) {
                $headlineTail = Get-HeadlineTail $headline
                if (-not [string]::IsNullOrWhiteSpace($headlineTail)) {
                    Write-DebugLookupMessage "Trying tail-based resolution for '$headline' with tail '$headlineTail'"

                    $tailExactMatches = @($lookupPairs | Where-Object {
                        (Get-HeadlineTail $_.Headline) -eq $headlineTail
                    })

                    if ($DebugLookup -and $tailExactMatches.Count -gt 0) {
                        foreach ($match in $tailExactMatches) {
                            Write-DebugLookupMessage "Tail exact match candidate: $($match.Headline) => $($match.Code)"
                        }
                    }

                    if ($tailExactMatches.Count -eq 1) {
                        $hit = $tailExactMatches[0]
                    } elseif ($tailExactMatches.Count -gt 1) {
                        $headlineIndex = Get-ManeuverIndex $headline
                        $headlineCodeHint = ($headlineNorm -split '\s+') | Select-Object -First 3
                        $rankedTailMatches = $tailExactMatches | ForEach-Object {
                            $candidateCodeNorm = Normalize-Text $_.Code
                            $candidateIndex = Get-ManeuverIndex $_.Headline
                            if ($null -eq $candidateIndex) {
                                $candidateIndex = Get-ManeuverIndex $_.Code
                            }

                            $distance = if ($null -eq $headlineIndex -or $null -eq $candidateIndex) {
                                [int]::MaxValue
                            } else {
                                [Math]::Abs($candidateIndex - $headlineIndex)
                            }

                            $hintScore = 0
                            foreach ($hint in $headlineCodeHint) {
                                if (-not [string]::IsNullOrWhiteSpace($hint) -and $candidateCodeNorm -like "*$hint*") {
                                    $hintScore += 1
                                }
                            }

                            [PSCustomObject]@{
                                Match = $_
                                HintScore = $hintScore
                                Distance = $distance
                            }
                        } | Sort-Object @{ Expression = 'HintScore'; Descending = $true }, @{ Expression = 'Distance'; Descending = $false }

                        if ($rankedTailMatches.Count -gt 1) {
                            $best = $rankedTailMatches[0]
                            $runnerUp = $rankedTailMatches[1]
                            if ($best.HintScore -gt $runnerUp.HintScore -or ($best.HintScore -eq $runnerUp.HintScore -and $best.Distance -lt $runnerUp.Distance)) {
                                $hit = $best.Match
                                Write-DebugLookupMessage "Resolved ambiguous tail exact match using code-token and index ranking: '$($hit.Code)'"
                            }
                        } elseif ($rankedTailMatches.Count -eq 1) {
                            $hit = $rankedTailMatches[0].Match
                        }

                        if (-not $hit) {
                            $options = ($tailExactMatches | ForEach-Object { "$($_.Headline) => $($_.Code)" }) -join '; '
                            throw "Headline '$headline' tail-matched multiple maneuver codes. Be more specific. Matches: $options"
                        }
                    } else {
                        $tailContainsMatches = @($lookupPairs | Where-Object {
                            $candidateTail = Get-HeadlineTail $_.Headline
                            -not [string]::IsNullOrWhiteSpace($candidateTail) -and (
                                $candidateTail -like "*$headlineTail*" -or $headlineTail -like "*$candidateTail*"
                            )
                        })

                        if ($DebugLookup -and $tailContainsMatches.Count -gt 0) {
                            foreach ($match in $tailContainsMatches) {
                                Write-DebugLookupMessage "Tail partial match candidate: $($match.Headline) => $($match.Code)"
                            }
                        }

                        if ($tailContainsMatches.Count -eq 1) {
                            $hit = $tailContainsMatches[0]
                        } elseif ($tailContainsMatches.Count -gt 1) {
                            $options = ($tailContainsMatches | ForEach-Object { "$($_.Headline) => $($_.Code)" }) -join '; '
                            throw "Headline '$headline' tail-partially matched multiple maneuver codes. Be more specific. Matches: $options"
                        }
                    }
                }
            }
            }
        }

        if (-not $hit) {
            $sample = ($lookupPairs | Select-Object -First 8 | ForEach-Object { "'$($_.Headline)' => '$($_.Code)'" }) -join '; '
            throw "Could not resolve maneuver code for headline: '$headline'. Available mappings sample: $sample. Tip: pass -ManeuverCodes directly if you already know the code."
        }

        Write-DebugLookupMessage "Resolved headline '$headline' to code '$($hit.Code)' via headline '$($hit.Headline)'"

        $resolvedHeadlines += $hit.Headline
        $resolvedCodes += $hit.Code
    }
}

$n = $resolvedCodes.Count
$sourceCatalogs = @($SourceCatalog) * $n
# ManeuverPath may contain multiple paths; split if needed and pass as array for all maneuvers.
$maneuverPaths = if ($ManeuverPath -match ';') {
    @($ManeuverPath -split ';' | ForEach-Object { $_.Trim() })
} else {
    @($ManeuverPath)
}

$maneuverPaths = @($maneuverPaths | Where-Object { -not [string]::IsNullOrWhiteSpace($_) -and (Test-Path -LiteralPath $_) } | Select-Object -Unique)
if ($maneuverPaths.Count -eq 0) {
    throw "No valid maneuver directories found in ManeuverPath: '$ManeuverPath'"
}

$availableManeuverFileStems = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
foreach ($path in $maneuverPaths) {
    Get-ChildItem -LiteralPath $path -Filter '*.cbm' -File -ErrorAction SilentlyContinue |
        ForEach-Object { [void]$availableManeuverFileStems.Add($_.BaseName) }
}

$missingManeuverCodes = @()
foreach ($code in @($resolvedCodes | Select-Object -Unique)) {
    $candidates = Get-ManeuverCodeStemCandidates -Code $code
    $exists = $false
    foreach ($candidate in $candidates) {
        if ($availableManeuverFileStems.Contains($candidate)) {
            $exists = $true
            break
        }
    }

    if (-not $exists) {
        $missingManeuverCodes += $code
    }
}

if ($missingManeuverCodes.Count -gt 0) {
    $missingList = ($missingManeuverCodes | Select-Object -Unique) -join '; '
    $pathsList = $maneuverPaths -join '; '
    throw "Resolved maneuver codes not found as .cbm files. Missing: $missingList. Checked directories: $pathsList"
}

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$cfgScript = Join-Path $scriptDir 'ViMP-cfg-creation.ps1'
if (-not (Test-Path -LiteralPath $cfgScript)) {
    throw "Required script not found: $cfgScript"
}

& $cfgScript `
    -ManeuverCodes $resolvedCodes `
    -ManeuverHeadlines $resolvedHeadlines `
    -SourceCatalogs $sourceCatalogs `
    -ManeuverPaths $maneuverPaths `
    -TemplatePath $TemplatePath `
    -OutputPath $OutputPath