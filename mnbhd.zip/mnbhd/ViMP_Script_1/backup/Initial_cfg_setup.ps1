param(
    [Alias('Codes')]
    [string[]]$ManeuverCodes,
    [switch]$DebugLookup,
    [string]$VmcRoot = 'C:\ViMP\ViMP26052910002021bW64\SimEnv_EXPORTED\util\VeDA\config\maneuvers',
    [string]$SourceCatalog = 'Verifizierung_VirtuellerFuhrpark - Inbetriebnahme_HCP1',
    [string]$ManeuverPath = 'C:\ViMP\ViMP26052910002021bW64\SimEnv_EXPORTED\util\VeDA\config\maneuvers',
    [string]$TemplatePath = 'C:\ViMP\ViMP.cfg',
    [string]$OutputPath = 'C:\ViMP\ViMP26052910002021bW64\ProjectsSE\991C2S_SEO390\ViMP.cfg'
)
 
# Hardcoded maneuver headline
$ManeuverHeadlines = @('HCP1 RTC: initial slow line maneuvering')
 
$ScriptVersion = 'Initial_cfg_setup.ps1 v2026-07-14.1'
Write-Host "Starting initial cfg setup..." -ForegroundColor Cyan
Write-Host "SCRIPT VERSION: $ScriptVersion" -ForegroundColor Magenta
 
# Allow plain trailing args as maneuver codes, e.g. .\Initial_cfg_setup.ps1 'FMT ...' 'FMT ...'
if (($null -eq $ManeuverCodes -or $ManeuverCodes.Count -eq 0) -and $args.Count -gt 0) {
    $ManeuverCodes = @($args)
}
 
if (($null -eq $ManeuverCodes -or $ManeuverCodes.Count -eq 0) -and ($null -eq $ManeuverHeadlines -or $ManeuverHeadlines.Count -eq 0)) {
    Write-Host "Provide at least one of: -ManeuverCodes or -ManeuverHeadlines" -ForegroundColor Yellow
    Write-Host "Examples:" -ForegroundColor Yellow
    Write-Host "  .\Initial_cfg_setup.ps1 -ManeuverCodes 'FMT PSM HOLD 0008 SLBSA','FMT PSM HOLD 0009 SLBS'"
    Write-Host "  .\Initial_cfg_setup.ps1 -ManeuverHeadlines 'HCP1 RTC: initial slow line maneuvering'"
    Write-Host "  .\Initial_cfg_setup.ps1 'FMT PSM HOLD 0008 SLBSA' 'FMT PSM HOLD 0009 SLBS'"
    exit 1
}
 
if (-not (Test-Path -LiteralPath $VmcRoot)) {
    throw "VmcRoot not found: $VmcRoot"
}
 
function Normalize-Text([string]$s) {
    if ($null -eq $s) { return '' }
    $norm = $s.Replace('_', ' ')
    $norm = ($norm -replace '\s+', ' ').Trim()
    return $norm.ToUpperInvariant()
}
 
function Test-ValidLookupPair($Pair) {
    if ($null -eq $Pair) { return $false }
    if ([string]::IsNullOrWhiteSpace($Pair.Code) -or [string]::IsNullOrWhiteSpace($Pair.Headline)) { return $false }
 
    $codeNorm = Normalize-Text $Pair.Code
    $headlineNorm = Normalize-Text $Pair.Headline
 
    if ($codeNorm.Length -lt 4 -or $headlineNorm.Length -lt 4) { return $false }
    if ($codeNorm -eq $headlineNorm) { return $false }
    if ($codeNorm -notmatch 'FMT|FUPA|HCP1|PSM|PPE|CSC|RTC|ADC|DSI|VDSO|SRC|AITV|INB') { return $false }
    return $true
}
 
function Write-DebugLookupMessage([string]$Message) {
    if ($DebugLookup) {
        Write-Host $Message -ForegroundColor DarkCyan
    }
}
 
# Build lookup table from OptHeadline <-> PostFcnManCode.
$vmcPairs = Get-ChildItem -Path $VmcRoot -Recurse -Filter '*.vmc' -File | ForEach-Object {
    $txt = Get-Content -LiteralPath $_.FullName -Raw
    [regex]::Matches($txt, "(?s)OptHeadline\s*=\s*'(?<h>[^']+)'.*?PostFcnManCode\s*=\s*'(?<c>[^']+)'") |
        ForEach-Object {
            [PSCustomObject]@{
                Code = $_.Groups['c'].Value
                Headline = $_.Groups['h'].Value
            }
        }
} | Where-Object { Test-ValidLookupPair $_ } | Sort-Object Code, Headline -Unique
 
function Get-CfgPairs([string]$CfgPath) {
    if (-not (Test-Path -LiteralPath $CfgPath)) { return @() }
 
    $cfgText = Get-Content -LiteralPath $CfgPath -Raw -Encoding UTF8
    $pairs = @()
 
    $optPairs = [regex]::Matches(
        $cfgText,
        "(?s)OptHeadline\s*=\s*'(?<h>[^']+)'.*?PostFcnManCode\s*=\s*'(?<c>[^']+)'"
    ) | ForEach-Object {
        [PSCustomObject]@{
            Code = $_.Groups['c'].Value
            Headline = $_.Groups['h'].Value
        }
    }
 
    if ($optPairs) {
        $pairs += $optPairs
    }
 
    # Fallback mapping from ManeuverCode/ManeuverString lists.
    $codeMatch = [regex]::Match($cfgText, '(?s)ManeuverCode\s*=\s*\{(?<body>.*?)\}')
    $stringMatch = [regex]::Match($cfgText, '(?s)ManeuverString\s*=\s*\{(?<body>.*?)\}')
    if ($codeMatch.Success -and $stringMatch.Success) {
        $codes = [regex]::Matches($codeMatch.Groups['body'].Value, "'([^']*)'") | ForEach-Object { $_.Groups[1].Value }
        $headlines = [regex]::Matches($stringMatch.Groups['body'].Value, "'([^']*)'") | ForEach-Object { $_.Groups[1].Value }
        $count = [Math]::Min($codes.Count, $headlines.Count)
        for ($i = 0; $i -lt $count; $i++) {
            $pairs += [PSCustomObject]@{
                Code = $codes[$i]
                Headline = $headlines[$i]
            }
        }
    }
 
    return @($pairs | Where-Object { Test-ValidLookupPair $_ } | Sort-Object Code, Headline -Unique)
}
 
$projectFallbackCfgPath = 'C:\ViMP\ViMP.cfg'
$cfgPaths = @($TemplatePath, $OutputPath, $projectFallbackCfgPath) | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | Select-Object -Unique
$cfgPairs = @()
foreach ($cfgPath in $cfgPaths) {
    $cfgPairs += Get-CfgPairs -CfgPath $cfgPath
}
$cfgPairs = @($cfgPairs | Where-Object { Test-ValidLookupPair $_ } | Sort-Object Code, Headline -Unique)
$lookupPairs = @($vmcPairs + $cfgPairs) | Where-Object { Test-ValidLookupPair $_ } | Sort-Object Code, Headline -Unique
 
Write-DebugLookupMessage "Lookup source VMC root: $VmcRoot"
foreach ($cfgPath in $cfgPaths) {
    Write-DebugLookupMessage "Lookup source CFG path: $cfgPath"
}
Write-DebugLookupMessage "Loaded VMC pairs: $($vmcPairs.Count)"
Write-DebugLookupMessage "Loaded CFG pairs: $($cfgPairs.Count)"
Write-DebugLookupMessage "Loaded total lookup pairs: $($lookupPairs.Count)"
 
if ($lookupPairs.Count -eq 0) {
    throw "No OptHeadline/PostFcnManCode mappings found in: $VmcRoot or $TemplatePath"
}
 
$resolvedCodes = @()
$resolvedHeadlines = @()
 
if ($ManeuverCodes -and $ManeuverCodes.Count -gt 0) {
    foreach ($code in $ManeuverCodes) {
        $resolvedCodes += $code
        $hit = $lookupPairs | Where-Object { (Normalize-Text $_.Code) -eq (Normalize-Text $code) } | Select-Object -First 1
        if ($hit) {
            Write-DebugLookupMessage "Resolved code '$code' to headline '$($hit.Headline)'"
            $resolvedHeadlines += $hit.Headline
        }
        else {
            # Fallback keeps cfg generation possible even if mapping is not in .vmc.
            Write-DebugLookupMessage "No headline mapping found for code '$code'; using code as headline fallback"
            $resolvedHeadlines += $code
        }
    }
}
else {
    foreach ($headline in $ManeuverHeadlines) {
        $hit = $null
        $headlineNorm = Normalize-Text $headline
        Write-DebugLookupMessage "Resolving headline '$headline' (normalized: '$headlineNorm')"
        $exactMatches = @($lookupPairs | Where-Object { (Normalize-Text $_.Headline) -eq $headlineNorm })
        if ($DebugLookup -and $exactMatches.Count -gt 0) {
            foreach ($match in $exactMatches) {
                Write-DebugLookupMessage "Exact match candidate: $($match.Headline) => $($match.Code)"
            }
        }
        if ($exactMatches.Count -gt 1) {
            $options = ($exactMatches | ForEach-Object { "$($_.Headline) => $($_.Code)" }) -join '; '
            throw "Headline '$headline' matched multiple maneuver codes. Be more specific. Matches: $options"
        }
 
        if ($exactMatches.Count -eq 1) {
            $hit = $exactMatches | Select-Object -First 1
        }
        else {
            $containsMatches = @($lookupPairs | Where-Object {
                $candidate = Normalize-Text $_.Headline
                $candidate -like "*$headlineNorm*" -or $headlineNorm -like "*$candidate*"
            })
 
            if ($DebugLookup -and $containsMatches.Count -gt 0) {
                foreach ($match in $containsMatches) {
                    Write-DebugLookupMessage "Partial match candidate: $($match.Headline) => $($match.Code)"
                }
            }
 
            if ($containsMatches.Count -gt 1) {
                $options = ($containsMatches | ForEach-Object { "$($_.Headline) => $($_.Code)" }) -join '; '
                throw "Headline '$headline' partially matched multiple maneuver codes. Be more specific. Matches: $options"
            }
            if ($containsMatches.Count -eq 1) {
                $hit = $containsMatches | Select-Object -First 1
            }
        }
 
        if (-not $hit) {
            throw "Could not resolve maneuver code for headline: '$headline'"
        }
 
        Write-DebugLookupMessage "Resolved headline '$headline' to code '$($hit.Code)' via headline '$($hit.Headline)'"
 
        $resolvedHeadlines += $hit.Headline
        $resolvedCodes += $hit.Code
    }
}
 
$n = $resolvedCodes.Count
$sourceCatalogs = @($SourceCatalog) * $n
$maneuverPaths = @($ManeuverPath) * $n
 
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$cfgScript = Join-Path $scriptDir 'ViMP-cfg-creation.ps1'
if (-not (Test-Path -LiteralPath $cfgScript)) {
    throw "Required script not found: $cfgScript"
}
 
& $cfgScript `
    -ManeuverCodes $resolvedCodes `
    -ManeuverHeadlines $resolvedHeadlines `
    -SourceCatalogs $sourceCatalogs `
    -ManeuverPaths $maneuverPaths `
    -TemplatePath $TemplatePath `
    -OutputPath $OutputPath